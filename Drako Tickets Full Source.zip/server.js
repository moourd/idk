const express = require('express');
const passport = require('passport');
const session = require('express-session');
const { Strategy } = require('passport-discord');
const Ticket = require('./models/tickets');
const yaml = require('js-yaml');
const fs = require('fs');
const path = require('path');
const client = require('./index');
const { WebhookClient } = require('discord.js');
const mongoose = require('mongoose');
const configPath = path.join(__dirname, './config.yml');
const config = yaml.load(fs.readFileSync(configPath, 'utf8'));
const moment = require('moment-timezone');
const sharp = require('sharp');

const app = express();

const timezone = config.Timezone || 'UTC';

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

passport.use(new Strategy({
    clientID: config.Dashboard.ClientID,
    clientSecret: config.Dashboard.ClientSecret,
    callbackURL: config.Dashboard.CallbackURL,
    scope: ['identify', 'guilds']
},
    (accessToken, refreshToken, profile, done) => {
        process.nextTick(() => done(null, profile));
    }));

app.use(session({
    secret: 'some secret',
    resave: false,
    saveUninitialized: false,
}));
app.use(passport.initialize());
app.use(passport.session());

app.use(express.urlencoded({ extended: true }));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

function ensureAuthenticated(req, res, next) {
    if (req.isAuthenticated()) return next();
    const redirectUrl = encodeURIComponent(req.originalUrl);
    res.redirect(`/auth/discord?redirect=${redirectUrl}`);
}

function ensureRole(roleIds) {
    return async function (req, res, next) {
        if (!req.isAuthenticated() || !req.user) {
            return res.render('noaccess', { user: req.user });
        }

        try {
            const guild = await client.guilds.fetch(config.GuildID);
            const member = await guild.members.fetch(req.user.id);
            const hasRole = roleIds.some(roleId => member.roles.cache.has(roleId));

            if (!hasRole) {
                return res.render('noaccess', { user: req.user });
            }

            next();
        } catch (error) {
            if (error.code === 10007) {
                return res.render('noaccess', { user: req.user });
            } else {
                console.error('Error checking user roles:', error);
                res.status(500).send('Internal Server Error');
            }
        }
    };
}

app.get('/auth/discord', (req, res, next) => {
    const state = req.query.redirect ? `redirect:${req.query.redirect}` : '';
    passport.authenticate('discord', { state })(req, res, next);
});

app.get('/auth/discord/callback', (req, res, next) => {
    passport.authenticate('discord', (err, user, info) => {
        if (err || !user) {
            console.error('Authentication error:', err || info);
            return res.redirect('/auth/discord');
        }

        req.logIn(user, (err) => {
            if (err) {
                console.error('Login error:', err);
                return res.redirect('/');
            }

            const state = req.query.state;
            let redirectUrl = '/';
            if (state && state.startsWith('redirect:')) {
                redirectUrl = decodeURIComponent(state.split(':')[1]);
            }

            res.redirect(redirectUrl);
        });
    })(req, res, next);
});

app.get('/logout', (req, res) => {
    req.logout(() => {
        res.redirect('/');
    });
});

app.get('/', ensureAuthenticated, (req, res) => {
    const user = {
        avatar: req.user.avatar ? `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png` : 'https://cdn.discordapp.com/embed/avatars/0.png',
        name: req.user.username || 'Unknown User'
    };
    res.render('landing', { user });
});

app.get('/ticket-logs', ensureAuthenticated, async (req, res) => {
    try {
        if (!req.user || !req.user.id) {
            console.error('User information is missing from the request');
            return res.status(400).send('Bad Request: User information is missing');
        }

        const userId = req.user.id;
        const user = {
            avatar: req.user.avatar ? `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png` : 'https://cdn.discordapp.com/embed/avatars/0.png',
            name: req.user.username || 'Unknown User'
        };

        const tickets = await Ticket.find({});

        const processedTickets = await Promise.all(tickets.map(async (ticket) => {
            let requesterName = ticket.userId;
            let requesterAvatar = 'https://cdn.discordapp.com/embed/avatars/0.png';
            try {
                if (ticket.userId) {
                    const requester = await client.users.fetch(ticket.userId).catch(() => null);
                    if (requester) {
                        requesterName = requester.tag;
                        requesterAvatar = requester.displayAvatarURL({ format: 'png' });
                    }
                }
            } catch (err) {
                if (err.code !== 10007) {
                    console.error(`Failed to fetch user with ID ${ticket.userId}`, err);
                }
            }

            let lastMessageDate = 'No messages';
            if (ticket.messages.length > 0) {
                lastMessageDate = ticket.messages.reduce((latest, message) =>
                    new Date(message.timestamp) > new Date(latest.timestamp) ? message : latest, ticket.messages[0]).timestamp;
            }

            return {
                ...ticket.toObject(),
                requesterName,
                requesterAvatar,
                lastMessageDate
            };
        }));

        const accessibleTickets = [];
        for (const ticket of processedTickets) {
            const ticketTypeConfig = config.TicketTypes[ticket.ticketType];

            if (!ticketTypeConfig) {
                console.warn(`No configuration found for ticket type ${ticket.ticketType}`);
                continue;
            }

            const supportRoles = ticketTypeConfig.SupportRole || [];

            if (!Array.isArray(supportRoles)) {
                console.warn(`Support roles for ticket type ${ticket.ticketType} are not an array. Skipping role check.`);
                continue;
            }

            let hasSupportRole = false;
            let member = null;
            try {
                const guild = await client.guilds.fetch(ticket.guildId);
                member = await guild.members.fetch(userId).catch(() => null);
                if (member) {
                    hasSupportRole = supportRoles.some(roleId => member.roles.cache.has(roleId));
                }
            } catch (error) {
                console.warn(`Failed to check roles for member ${userId} in guild ${ticket.guildId}`, error);
            }

            if (ticket.userId === userId || hasSupportRole || (ticket.supportAgents && ticket.supportAgents.includes(userId))) {
                accessibleTickets.push(ticket);
            }
        }

        const uniqueOwners = [...new Set(processedTickets.map(ticket => ticket.requesterName))].filter(name => name);

        res.render('ticketlogs', { user, tickets: accessibleTickets, owners: uniqueOwners });
    } catch (error) {
        console.error('Error fetching tickets:', error);
        res.status(500).send('Internal Server Error');
    }
});

function processMarkdown(content) {
    return content
        .replace(/\*\*(.*?)\*\*/g, '<span class="discord-bold">$1</span>')
        .replace(/\*(.*?)\*/g, '<span class="discord-italic">$1</span>')
        .replace(/__(.*?)__/g, '<span class="discord-underline">$1</span>')
        .replace(/~~(.*?)~~/g, '<span class="discord-strikethrough">$1</span>')
        .replace(/```([^]+?)```/g, '<pre class="discord-codeblock">$1</pre>')
        .replace(/`(.*?)`/g, '<span class="discord-code">$1</span>')
        .replace(/^>(.*?)$/gm, '<div class="discord-blockquote">$1</div>');
}

async function compressAndConvertToBase64(imageBuffer, contentType) {
    let compressedBuffer;

    switch (contentType) {
        case 'image/jpeg':
            compressedBuffer = await sharp(imageBuffer)
                .jpeg({ quality: 70 })
                .toBuffer();
            break;
        case 'image/png':
            compressedBuffer = await sharp(imageBuffer)
                .png({ compressionLevel: 9 })
                .toBuffer();
            break;
        case 'image/webp':
            compressedBuffer = await sharp(imageBuffer)
                .webp({ quality: 70 })
                .toBuffer();
            break;
        default:
            compressedBuffer = imageBuffer;
            break;
    }

    return compressedBuffer.toString('base64');
}

app.get('/transcript/:id', ensureAuthenticated, async (req, res) => {
    try {
        const ticket = await Ticket.findOne({ ticketId: req.params.id });
        if (!ticket) {
            return res.status(404).send('Ticket not found');
        }

        const userId = req.user.id;
        const isOwner = ticket.userId === userId;
        const isSupportAgent = ticket.supportAgents && ticket.supportAgents.includes(userId);
        const guild = await client.guilds.fetch(ticket.guildId);
        const member = await guild.members.fetch(userId).catch(() => null);
        const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole || [];
        const hasSupportRole = member ? supportRoles.some(roleId => member.roles.cache.has(roleId)) : false;

        if (!isOwner && !isSupportAgent && !hasSupportRole) {
            return res.render('noaccess', { user: req.user });
        }

        const ticketMessages = ticket.messages || [];

        const formatDiscordMentions = (content) => {
            return content
                .replace(/<@!?(\d+)>/g, (match, userId) => {
                    const user = client.users.cache.get(userId);
                    if (user) {
                        return `<span class="mention">@${user.username}</span>`;
                    }
                    return match;
                })
                .replace(/<@&(\d+)>/g, (match, roleId) => {
                    const role = client.guilds.cache.get(config.GuildID).roles.cache.get(roleId);
                    if (role) {
                        return `<span class="mention">@${role.name}</span>`;
                    }
                    return match;
                })
                .replace(/<#(\d+)>/g, (match, channelId) => {
                    const channel = client.channels.cache.get(channelId);
                    if (channel) {
                        return `<span class="mention">#${channel.name}</span>`;
                    }
                    return match;
                });
        };

        const messages = await Promise.all(ticketMessages.map(async (message) => {
            let isSupport = false;
            let isOwner = false;
            let processedAttachments = [];

            if (message.attachments && message.attachments.length > 0) {
                processedAttachments = await Promise.all(message.attachments.map(async (attachment) => {
                    if (attachment.contentType && attachment.contentType.startsWith('image/')) {
                        const imageBuffer = Buffer.from(attachment.base64, 'base64');
                        const compressedBase64 = await compressAndConvertToBase64(imageBuffer, attachment.contentType);

                        return {
                            ...attachment.toObject(),
                            base64: compressedBase64
                        };
                    }

                    return attachment.toObject();
                }));
            }

            if (message.authorId) {
                try {
                    const user = await client.users.fetch(message.authorId).catch(() => null);
                    const member = user ? await client.guilds.cache.get(ticket.guildId).members.fetch(message.authorId).catch(() => null) : null;
                    if (member) {
                        isSupport = config.TicketTypes[ticket.ticketType].SupportRole.some(roleId => member.roles.cache.has(roleId));
                        isOwner = message.authorId === ticket.userId;
                    }

                    return {
                        ...message.toObject(),
                        avatar: user ? user.displayAvatarURL({ format: 'png' }) : 'https://cdn.discordapp.com/embed/avatars/0.png',
                        author: user ? user.tag : 'Unknown User',
                        isSupport: !isOwner && isSupport,
                        isOwner: isOwner,
                        formattedTimestamp: moment(message.timestamp).tz(timezone).format('HH:mm'),
                        content: processMarkdown(formatDiscordMentions(message.content)),
                        attachments: processedAttachments
                    };
                } catch (error) {
                }
            }
            return {
                ...message.toObject(),
                avatar: 'https://cdn.discordapp.com/embed/avatars/0.png',
                author: message.author || 'Unknown User',
                isSupport: false,
                isOwner: false,
                formattedTimestamp: moment(message.timestamp).tz(timezone).format('HH:mm'),
                content: processMarkdown(formatDiscordMentions(message.content)),
                attachments: processedAttachments
            };
        }));

        const participants = await Promise.all([...new Set(messages.map(msg => msg.authorId))].map(async id => {
            if (!id) return { id, name: 'Unknown User', avatar: 'https://cdn.discordapp.com/embed/avatars/0.png' };
            try {
                const user = await client.users.fetch(id).catch(() => null);
                return {
                    id,
                    name: user ? user.tag : 'Unknown User',
                    avatar: user ? user.displayAvatarURL({ format: 'png' }) : 'https://cdn.discordapp.com/embed/avatars/0.png'
                };
            } catch (error) {
                return {
                    id,
                    name: 'Unknown User',
                    avatar: 'https://cdn.discordapp.com/embed/avatars/0.png'
                };
            }
        }));

        const guildName = guild ? guild.name : 'Unknown Guild';
        const isStaff = hasSupportRole;

        res.render('transcript', {
            ticket,
            messages,
            guildName,
            messageCount: messages.length,
            questions: ticket.questions || [],
            participants,
            summary: {
                openDate: moment(ticket.createdAt).tz(timezone).format('YYYY-MM-DD HH:mm:ss z'),
                closureDate: ticket.closedAt ? moment(ticket.closedAt).tz(timezone).format('YYYY-MM-DD HH:mm:ss z') : 'Open',
                review: ticket.rating,
                reviewReason: ticket.reviewFeedback
            },
            isStaff: isStaff,
            isOpen: !ticket.closedAt,
        });
    } catch (error) {
        console.error('Error rendering transcript:', error);
        res.status(500).send('Internal Server Error');
    }
});

async function createWebhook(channel, name, avatarURL) {
    if (!name) {
        console.error('Webhook name is undefined');
        throw new Error('Webhook name is required');
    }
    if (!avatarURL) {
        console.error('Webhook avatarURL is undefined');
        throw new Error('Webhook avatarURL is required');
    }
    try {
        const webhook = await channel.createWebhook({
            name: name,
            avatar: avatarURL,
        });
        return webhook;
    } catch (error) {
        console.error('Error creating webhook:', error);
        throw error;
    }
}

async function deleteWebhook(webhook) {
    try {
        await webhook.delete();
    } catch (error) {
        console.error('Error deleting webhook:', error);
        throw error;
    }
}

app.get('/transcript/:id/messages', ensureAuthenticated, async (req, res) => {
    try {
        const ticket = await Ticket.findOne({ ticketId: req.params.id });
        if (!ticket) {
            return res.status(404).send('Ticket not found');
        }

        const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole;
        const messages = await Promise.all(ticket.messages.map(async (message) => {
            let isSupport = false;
            let processedAttachments = [];

            if (message.attachments && message.attachments.length > 0) {
                processedAttachments = await Promise.all(message.attachments.map(async (attachment) => {
                    if (attachment.contentType && attachment.contentType.startsWith('image/')) {
                        const imageBuffer = Buffer.from(attachment.base64, 'base64');
                        const compressedBase64 = await compressAndConvertToBase64(imageBuffer, attachment.contentType);

                        return {
                            ...attachment.toObject(),
                            base64: compressedBase64
                        };
                    }

                    return attachment.toObject();
                }));
            }

            if (message.authorId) {
                try {
                    const user = await client.users.fetch(message.authorId);
                    const guild = await client.guilds.fetch(ticket.guildId);
                    const member = await guild.members.fetch(message.authorId);
                    isSupport = supportRoles.some(roleId => member.roles.cache.has(roleId));
                    const isOwner = message.authorId === ticket.userId;

                    return {
                        ...message.toObject(),
                        avatar: user.displayAvatarURL({ format: 'png' }),
                        author: user.tag,
                        isSupport: !isOwner && isSupport,
                        isOwner: isOwner,
                        formattedTimestamp: moment(message.timestamp).tz(timezone).format('HH:mm'),
                        content: processMarkdown(message.content),
                        attachments: processedAttachments
                    };
                } catch (error) {
                    if (error.code === 10007) {
                    } else {
                        console.error(`Failed to fetch user with ID ${message.authorId}`, error);
                    }
                }
            }
            return {
                ...message.toObject(),
                avatar: 'https://cdn.discordapp.com/embed/avatars/0.png',
                author: message.author || 'Unknown User',
                isSupport: false,
                isOwner: false,
                formattedTimestamp: moment(message.timestamp).tz(timezone).format('HH:mm'),
                content: processMarkdown(message.content),
                attachments: processedAttachments
            };
        }));

        const participants = await Promise.all([...new Set(messages.map(msg => msg.authorId))].map(async id => {
            if (!id) return { id, name: 'Unknown User', avatar: 'https://cdn.discordapp.com/embed/avatars/0.png' };
            try {
                const user = await client.users.fetch(id);
                return {
                    id,
                    name: user.tag,
                    avatar: user.displayAvatarURL({ format: 'png' })
                };
            } catch (error) {
                if (error.code === 10007) {
                } else {
                    console.error(`Failed to fetch user with ID ${id}`, error);
                }
                return {
                    id,
                    name: 'Unknown User',
                    avatar: 'https://cdn.discordapp.com/embed/avatars/0.png'
                };
            }
        }));

        res.json({ messages, participants, messageCount: messages.length });
    } catch (error) {
        console.error('Error fetching messages:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/send-message/:id', ensureAuthenticated, async (req, res) => {
    try {
        const ticket = await Ticket.findOne({ ticketId: req.params.id });
        if (!ticket) {
            return res.status(404).send('Ticket not found');
        }

        const ticketTypeConfig = config.TicketTypes[ticket.ticketType];
        const supportRoles = ticketTypeConfig.SupportRole;
        const userId = req.user.id;

        const guild = await client.guilds.fetch(ticket.guildId);
        const member = await guild.members.fetch(userId);

        const hasSupportRole = supportRoles.some(roleId => member.roles.cache.has(roleId));
        if (!hasSupportRole) {
            return res.status(403).send('You do not have permission to send messages in this ticket');
        }

        const channel = await client.channels.fetch(ticket.channelId);
        const avatarURL = req.user.avatar ? `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png` : 'https://cdn.discordapp.com/embed/avatars/0.png';

        const username = req.user.username || 'Unknown User';
        const webhook = await createWebhook(channel, username, avatarURL);

        const webhookClient = new WebhookClient({ id: webhook.id, token: webhook.token });

        const messageContent = req.body.messageContent;
        await webhookClient.send({
            content: messageContent,
            username: username,
            avatarURL: avatarURL,
        });

        await deleteWebhook(webhook);

        ticket.messages.push({
            authorId: req.user.id,
            content: messageContent,
            timestamp: new Date(),
            isWebhook: true
        });
        await ticket.save();

        res.redirect(`/transcript/${req.params.id}`);
    } catch (error) {
        console.error('Error sending message:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/statistics', ensureAuthenticated, ensureRole(config.Dashboard.Access.Statistics), (req, res) => {
    const user = {
        avatar: req.user.avatar ? `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png` : 'https://cdn.discordapp.com/embed/avatars/0.png',
        name: req.user.username || 'Unknown User'
    };

    if (user.name === 'Unknown User' || !req.user.id) {
        return res.render('noaccess', { user });
    }

    res.render('statistics', { user });
});

app.get('/api/member-count', ensureAuthenticated, ensureRole(config.Dashboard.Access.Statistics), async (req, res) => {
    try {
        const guild = await client.guilds.fetch(config.GuildID);
        const memberCount = guild.memberCount;
        res.json({ count: memberCount });
    } catch (error) {
        console.error('Error fetching member count:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/api/member-stats', ensureAuthenticated, ensureRole(config.Dashboard.Access.Statistics), async (req, res) => {
    try {
        const { duration } = req.query;
        const now = new Date();
        let startDate;

        switch (duration) {
            case '1d':
                startDate = new Date(now.getTime() - (24 * 60 * 60 * 1000));
                break;
            case '1w':
                startDate = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
                break;
            case '2w':
                startDate = new Date(now.getTime() - (14 * 24 * 60 * 60 * 1000));
                break;
            case '1m':
                startDate = new Date(now.setMonth(now.getMonth() - 1));
                break;
            case '3m':
                startDate = new Date(now.setMonth(now.getMonth() - 3));
                break;
            case '6m':
                startDate = new Date(now.setMonth(now.getMonth() - 6));
                break;
            case '1y':
                startDate = new Date(now.setFullYear(now.getFullYear() - 1));
                break;
            default:
                return res.status(400).send('Invalid duration');
        }

        const guild = await client.guilds.fetch(config.GuildID);
        const members = await guild.members.fetch();

        const memberJoinDates = members.map(member => member.joinedAt).sort((a, b) => a - b);

        let date = new Date(startDate);
        const labels = [];
        const data = [];
        let currentCount = 0;

        while (date <= now) {
            const formattedDate = date.toISOString().split('T')[0];
            labels.push(formattedDate);

            while (memberJoinDates.length && memberJoinDates[0] <= date) {
                memberJoinDates.shift();
                currentCount++;
            }

            data.push(currentCount);
            date.setDate(date.getDate() + 1);
        }

        const memberCountData = {
            labels,
            datasets: [
                {
                    label: 'Members in Server',
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    data
                }
            ]
        };

        res.json({
            memberCountData
        });
    } catch (error) {
        console.error('Error fetching member stats:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/api/ticket-stats', ensureAuthenticated, ensureRole(config.Dashboard.Access.Statistics), async (req, res) => {
    try {
        const { duration } = req.query;
        const now = new Date();
        let startDate;

        switch (duration) {
            case '1d':
                startDate = new Date(now.getTime() - (24 * 60 * 60 * 1000));
                break;
            case '1w':
                startDate = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
                break;
            case '2w':
                startDate = new Date(now.getTime() - (14 * 24 * 60 * 60 * 1000));
                break;
            case '1m':
                startDate = new Date(now.setMonth(now.getMonth() - 1));
                break;
            case '3m':
                startDate = new Date(now.setMonth(now.getMonth() - 3));
                break;
            case '6m':
                startDate = new Date(now.setMonth(now.getMonth() - 6));
                break;
            case '1y':
                startDate = new Date(now.setFullYear(now.getFullYear() - 1));
                break;
            default:
                return res.status(400).send('Invalid duration');
        }

        const ticketCountOverTime = await Ticket.aggregate([
            { $match: { createdAt: { $gte: startDate } } },
            {
                $group: {
                    _id: {
                        $dateToString: {
                            format: "%Y-%m-%d",
                            date: "$createdAt"
                        }
                    },
                    count: { $sum: 1 }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        const ticketCountData = {
            labels: ticketCountOverTime.map(item => item._id),
            datasets: [
                {
                    label: 'Tickets Created',
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    data: ticketCountOverTime.map(item => item.count)
                }
            ]
        };

        res.json({
            ticketCountData
        });
    } catch (error) {
        console.error('Error fetching ticket stats:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/api/ticket-count', ensureAuthenticated, ensureRole(config.Dashboard.Access.Statistics), async (req, res) => {
    try {
        const ticketCount = await Ticket.countDocuments();
        res.json({ count: ticketCount });
    } catch (error) {
        console.error('Error fetching ticket count:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/api/message-count', ensureAuthenticated, ensureRole(config.Dashboard.Access.Statistics), async (req, res) => {
    try {
        const messageCount = await Ticket.aggregate([
            { $unwind: "$messages" },
            { $count: "totalMessages" }
        ]);
        const count = messageCount[0] ? messageCount[0].totalMessages : 0;
        res.json({ count });
    } catch (error) {
        console.error('Error fetching message count:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/api/top-customers', ensureAuthenticated, ensureRole(config.Dashboard.Access.Statistics), async (req, res) => {
    try {
        const limit = parseInt(req.query.limit, 10) || 10;
        const offset = parseInt(req.query.offset, 10) || 0;

        const tickets = await Ticket.aggregate([
            { $group: { _id: '$userId', ticketCount: { $sum: 1 } } },
            { $sort: { ticketCount: -1 } },
            { $skip: offset },
            { $limit: limit }
        ]);

        const topCustomers = await Promise.all(tickets.map(async (ticket) => {
            try {
                const user = await client.users.fetch(ticket._id);
                return {
                    name: user.tag,
                    avatar: user.displayAvatarURL({ format: 'png' }),
                    ticketCount: ticket.ticketCount
                };
            } catch (error) {
                console.error(`Failed to fetch user with ID ${ticket._id}`, error);
                return {
                    name: 'Unknown User',
                    avatar: 'https://cdn.discordapp.com/embed/avatars/0.png',
                    ticketCount: ticket.ticketCount
                };
            }
        }));

        res.json({ customers: topCustomers });
    } catch (error) {
        console.error('Error fetching top customers:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.use((req, res, next) => {
    res.status(404).render('404');
});

module.exports = app;