﻿if (process.platform !== "win32") require("child_process").exec("npm install");

const colors = require('colors');
console.log(`${colors.brightGreen(`Starting bot, this can take a while..`)}`);

const fs = require('fs');
const packageFile = require('./package.json');
let logMsg = `\n\n[${new Date().toLocaleString()}] [STARTING] Attempting to start the bot..\nNodeJS Version: ${process.version}\nBot Version: ${packageFile.version}`;
fs.appendFile("./logs.txt", logMsg, (e) => {
    if (e) console.log(e);
});

const version = Number(process.version.split('.')[0].replace('v', ''));
if (version < 18) {
    console.log(`${colors.red(`[ERROR] Drako Tickets requires a NodeJS version of 18 or higher!\nYou can check your NodeJS by running the "node -v" command in your terminal.`)}`);

    console.log(`${colors.blue(`\n[INFO] To update Node.js, follow the instructions below for your operating system:`)}`);
    console.log(`${colors.green(`- Windows:`)} Download and run the installer from ${colors.cyan(`https://nodejs.org/`)}`);
    console.log(`${colors.green(`- Ubuntu/Debian:`)} Run the following commands in the Terminal:`);
    console.log(`${colors.cyan(`  - sudo apt update`)}`);
    console.log(`${colors.cyan(`  - sudo apt upgrade nodejs`)}`);
    console.log(`${colors.green(`- CentOS:`)} Run the following commands in the Terminal:`);
    console.log(`${colors.cyan(`  - sudo yum update`)}`);
    console.log(`${colors.cyan(`  - sudo yum install -y nodejs`)}`);

    let logMsg = `\n\n[${new Date().toLocaleString()}] [ERROR] Drako Tickets requires a NodeJS version of 18 or higher!`;
    fs.appendFile("./logs.txt", logMsg, (e) => {
        if (e) console.log(e);
    });

    process.exit()
}

const { Collection, Client, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Discord = require('discord.js');
const axios = require('axios');
const mongoManager = require('./models/manager.js');

mongoManager()
    .then(() => {
    })
    .catch((error) => {
        console.error(`Failed to connect to MongoDB: ${error.message}`);
    });

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.MessageContent
    ]
});

module.exports = client
require("./utils.js");

const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))

const filePath = './logs.txt';
const maxLength = 300;

if (config.Dashboard.Enabled) {
    const port = config.Dashboard.Port || 3000;

    const app = require('./server');
    const PORT = port || process.env.PORT || 3000;

    app.listen(PORT, () => {
        console.log(`${colors.bgBrightCyan.brightWhite(' SERVER ')} Running on port ${PORT}`);
    });
} else {
    console.log(`${colors.bgBrightCyan.brightWhite(' SERVER ')} Dashboard is not enabled`);
}