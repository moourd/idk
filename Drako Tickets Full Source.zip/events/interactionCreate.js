﻿const {
    ActionRowBuilder,
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    AttachmentBuilder,
    StringSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ChannelType,
    ThreadAutoArchiveDuration
} = require('discord.js');
const fs = require('fs');
const yaml = require("js-yaml");
const axios = require('axios');
const sharp = require('sharp');
const path = require('path');
const natural = require('natural');
const moment = require('moment-timezone');
const configPath = path.join(__dirname, '../config.yml');
const langPath = path.join(__dirname, '../lang.yml');
const config = yaml.load(fs.readFileSync(configPath, 'utf8'));
const lang = yaml.load(fs.readFileSync(langPath, 'utf8'));
const Ticket = require('../models/tickets');
const Blacklist = require('../models/blacklist');
const client = require("../index");

const phrases = [];
for (const key in config.SmartResponses.Phrases) {
    const item = config.SmartResponses.Phrases[key];
    item.Phrase.forEach(phrase => {
        phrases.push({
            ...item,
            key,
            tokens: natural.PorterStemmer.tokenizeAndStem(phrase),
            MatchPercent: item.MatchPercent || 0.80
        });
    });
}

async function getSmartResponse(userMessage, memberRoles) {
    try {
        if (!config.SmartResponses.Enabled) {
            return null;
        }

        const tokens = natural.PorterStemmer.tokenizeAndStem(userMessage.toLowerCase());

        const matches = phrases.map(p => ({
            ...p,
            score: natural.JaroWinklerDistance(tokens.join(' '), p.tokens.join(' '))
        }))
            .filter(p => p.score >= p.MatchPercent)
            .sort((a, b) => b.score - a.score);


        if (matches.length > 0) {
            const bestMatch = matches[0];

            if (bestMatch.Roles && Array.isArray(memberRoles)) {
                const hasRole = bestMatch.Roles.some(role => memberRoles.includes(role));

                if (hasRole && bestMatch.HasRoleResponse) {
                    return { type: 'TEXT', content: bestMatch.HasRoleResponse };
                } else if (!hasRole && bestMatch.NoRoleResponse) {
                    return { type: 'TEXT', content: bestMatch.NoRoleResponse };
                } else if (hasRole && bestMatch.HasRoleEmbed) {
                    const embed = new EmbedBuilder()
                        .setTitle(bestMatch.HasRoleEmbed.Title)
                        .setDescription(bestMatch.HasRoleEmbed.Description.join('\n'))
                        .setColor(bestMatch.HasRoleEmbed.Color)
                        .setFooter({ text: bestMatch.HasRoleEmbed.Footer.Text, iconURL: bestMatch.HasRoleEmbed.Footer.Icon });

                    return { type: 'EMBED', embed };
                } else if (!hasRole && bestMatch.NoRoleEmbed) {
                    const embed = new EmbedBuilder()
                        .setTitle(bestMatch.NoRoleEmbed.Title)
                        .setDescription(bestMatch.NoRoleEmbed.Description.join('\n'))
                        .setColor(bestMatch.NoRoleEmbed.Color)
                        .setFooter({ text: bestMatch.NoRoleEmbed.Footer.Text, iconURL: bestMatch.NoRoleEmbed.Footer.Icon });

                    return { type: 'EMBED', embed };
                }
            }

            if (bestMatch.Type === 'TEXT') {
                return { type: 'TEXT', content: bestMatch.Response };
            } else if (bestMatch.Type === 'EMBED' && bestMatch.Embed) {
                const embed = new EmbedBuilder()
                    .setTitle(bestMatch.Embed.Title || 'Default Title')
                    .setDescription(bestMatch.Embed.Description ? bestMatch.Embed.Description.join('\n') : 'Default Description')
                    .setColor(bestMatch.Embed.Color || '#000000')
                    .setFooter({
                        text: bestMatch.Embed.Footer ? bestMatch.Embed.Footer.Text : 'Default Footer',
                        iconURL: bestMatch.Embed.Footer ? bestMatch.Embed.Footer.Icon : null
                    });

                return { type: 'EMBED', embed };
            } else {
                //      console.error('Unexpected bestMatch Type:', bestMatch.Type);
            }
        }
    } catch (error) {
        console.error('Error handling smart response:', error);
    }
    return null;
}

function hasSupportRole(member, supportRoles) {
    const memberRoles = member.roles.cache.map(role => role.id);
    return supportRoles.some(roleId => memberRoles.includes(roleId));
}


function parseDuration(duration) {
    const timeUnits = {
        s: 1000,
        m: 1000 * 60,
        h: 1000 * 60 * 60,
        d: 1000 * 60 * 60 * 24,
    };

    const regex = /^(\d+)([smhd])?$/;
    const match = regex.exec(duration);

    if (!match) {
        throw new Error(`Invalid duration format: ${duration}`);
    }

    const value = parseInt(match[1], 10);
    const unit = match[2] || 's';

    return { value, unit, durationMs: value * timeUnits[unit] };
}

async function processTicketDeletion(client, interaction, ticket) {
    try {
        const ticketType = config.TicketTypes[ticket.ticketType];

        if (ticketType && ticketType.RestrictDeletion) {
            const memberRoles = interaction.member.roles.cache.map(role => role.id);
            const hasSupportRole = ticketType.SupportRole.some(roleId => memberRoles.includes(roleId));

            if (!hasSupportRole) {
                const responseMessage = lang.NoPermsMessage;
                await replyOrFollowUp(interaction, responseMessage);
                return;
            }
        }

        if (ticket.status === 'deleting' || ticket.status === 'deleted') {
            const responseMessage = lang.Tickets.Deleting;
            await replyOrFollowUp(interaction, responseMessage);
            return;
        }

        const updatedTicket = await Ticket.findOneAndUpdate(
            { ticketId: ticket.ticketId, status: { $nin: ['deleting', 'deleted'] } },
            { status: 'deleting' },
            { new: true }
        );

        if (!updatedTicket) {
            const responseMessage = lang.Tickets.Deleting;
            await replyOrFollowUp(interaction, responseMessage);
            return;
        }

        const channel = await client.channels.fetch(ticket.channelId).catch(() => null);
        if (!channel) {
            await Ticket.findOneAndUpdate(
                { ticketId: ticket.ticketId },
                { status: 'deleted', deletedAt: new Date() },
                { new: true }
            );
            await replyOrFollowUp(interaction, 'Ticket deleted but the channel no longer exists.');
            return;
        }

        const { value, durationMs } = parseDuration(config.TicketSettings.DeletionTime);

        const fetchedMessages = await channel.messages.fetch({ limit: 100 });
        const userMessages = fetchedMessages.filter(m => !m.author.bot);

        if (durationMs > 0) {
            const countdownEmbed = new EmbedBuilder()
                .setDescription(lang.Tickets.DeleteCountDown.replace('{time}', value))
                .setColor('#FF0000');

            await channel.send({ embeds: [countdownEmbed] });

            setTimeout(async () => {
                await handleChannelDeletion(client, interaction, channel, userMessages, updatedTicket);
            }, durationMs);
        } else {
            setTimeout(async () => {
                await handleChannelDeletion(client, interaction, channel, userMessages, updatedTicket);
            }, 1000);
        }
    } catch (error) {
        console.error(`Error handling ticket deletion:`, error);
        const responseMessage = 'An error occurred while processing the ticket. Please try again later.';
        await replyOrFollowUp(interaction, responseMessage);
    }
}

async function handleChannelDeletion(client, interaction, channel, userMessages, updatedTicket) {
    try {
        await sendDMEmbedAndTranscript(client, interaction, updatedTicket, 'delete', userMessages);

        if (channel.isThread()) {
            await channel.delete();
        } else if (channel.deletable) {
            await channel.delete();
        } else {
            console.error('Channel is not deletable.');
        }

        await Ticket.findOneAndUpdate(
            { ticketId: updatedTicket.ticketId },
            { status: 'deleted', deletedAt: new Date() },
            { new: true }
        );
    } catch (channelError) {
        console.error('Error deleting the channel:', channelError);
        if (channelError.code === 10003) {
            await Ticket.findOneAndUpdate(
                { ticketId: updatedTicket.ticketId },
                { status: 'deleted', deletedAt: new Date() },
                { new: true }
            );
        }
    }
}


async function handleDeleteTicket(client, interaction, uniqueId) {
    try {
        const ticket = await Ticket.findOne({ ticketId: uniqueId });

        if (!ticket) {
            const responseMessage = 'Ticket not found.';
            console.error(`No ticket found in the database with ticketId: ${uniqueId}`);
            await replyOrFollowUp(interaction, responseMessage);
            return;
        }

        await deferIfNeeded(interaction);
        await processTicketDeletion(client, interaction, ticket);
    } catch (error) {
        console.error('Error handling delete ticket:', error);
        await replyOrFollowUp(interaction, 'An error occurred while processing the ticket deletion. Please try again later.');
    }
}

async function handleTicketClose(client, interaction, uniqueId) {
    try {
        const reason = interaction.options?.getString('reason') || lang.NoReason;
        const ticket = await Ticket.findOne({ ticketId: uniqueId });

        if (!ticket) {
            const responseMessage = 'Ticket not found.';
            console.error(`No ticket found in the database with ticketId: ${uniqueId}`);
            await replyOrFollowUp(interaction, responseMessage);
            return;
        }

        const ticketType = config.TicketTypes[ticket.ticketType];

        if (ticket.status === 'deleting' || ticket.status === 'deleted') {
            const responseMessage = lang.Tickets.Deleting;
            await replyOrFollowUp(interaction, responseMessage);
            return;
        }

        const archiveCategoryId = ticketType && ticketType.ArchiveCategory;
        const isArchived = interaction.channel && interaction.channel.parentId === archiveCategoryId;

        if (ticket.status === 'closed') {
            await deferIfNeeded(interaction);
            if (archiveCategoryId && interaction.channel && !interaction.channel.isThread() && !isArchived) {
                const archiveCategory = interaction.guild.channels.cache.get(archiveCategoryId);
                if (archiveCategory) {
                    await interaction.channel.setParent(archiveCategory.id, { lockPermissions: false });
                }

                await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                    ViewChannel: false
                });

                const member = await interaction.guild.members.fetch(ticket.userId).catch(() => null);
                if (member) {
                    await interaction.channel.permissionOverwrites.edit(ticket.userId, {
                        ViewChannel: true,
                        SendMessages: false,
                        ReadMessageHistory: true,
                        AttachFiles: false,
                        EmbedLinks: false
                    });
                }

                for (const roleid of ticketType.SupportRole) {
                    const role = interaction.guild.roles.cache.get(roleid);
                    if (role) {
                        await interaction.channel.permissionOverwrites.edit(role, {
                            ViewChannel: true,
                            SendMessages: true,
                            ReadMessageHistory: true,
                            AttachFiles: true,
                            EmbedLinks: true
                        });
                    }
                }

                await sendArchiveEmbed(interaction, uniqueId, ticket.userId, reason);
                return;
            } else {
                await replyOrFollowUp(interaction, lang.Tickets.Deleting);
                await processTicketDeletion(client, interaction, ticket);
                return;
            }
        }

        await deferIfNeeded(interaction);

        ticket.alertMessageId = null;
        ticket.alertTime = null;

        const updatedTicket = await Ticket.findOneAndUpdate(
            { ticketId: uniqueId, status: { $nin: ['deleting', 'deleted', 'closed'] } },
            { status: 'closed', closedAt: new Date(), closeReason: reason, alertMessageId: null, alertTime: null },
            { new: true }
        );

        if (!updatedTicket) {
            const responseMessage = lang.Tickets.Closed;
            await replyOrFollowUp(interaction, responseMessage);
            return;
        }

        const channel = await client.channels.fetch(ticket.channelId).catch(() => null);
        if (!channel) {
            await Ticket.findOneAndUpdate(
                { ticketId: ticket.ticketId },
                { status: 'deleted', deletedAt: new Date(), closeReason: reason },
                { new: true }
            );
            await replyOrFollowUp(interaction, 'Ticket closed but the channel no longer exists.');
            return;
        }

        if (archiveCategoryId && !channel.isThread() && !isArchived) {
            const archiveCategory = interaction.guild.channels.cache.get(archiveCategoryId);
            if (archiveCategory) {
                await channel.setParent(archiveCategory.id, { lockPermissions: false });
            }

            await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                ViewChannel: false
            });

            const member = await interaction.guild.members.fetch(ticket.userId).catch(() => null);
            if (member) {
                await channel.permissionOverwrites.edit(ticket.userId, {
                    ViewChannel: true,
                    SendMessages: false,
                    ReadMessageHistory: true,
                    AttachFiles: false,
                    EmbedLinks: false
                });
            }

            for (const roleid of ticketType.SupportRole) {
                const role = interaction.guild.roles.cache.get(roleid);
                if (role) {
                    await channel.permissionOverwrites.edit(role, {
                        ViewChannel: true,
                        SendMessages: true,
                        ReadMessageHistory: true,
                        AttachFiles: true,
                        EmbedLinks: true
                    });
                }
            }

            await sendArchiveEmbed(interaction, uniqueId, ticket.userId, reason);
        } else {
            await processTicketDeletion(client, interaction, updatedTicket);
        }
    } catch (error) {
        console.error('Error handling ticket closing:', error);
        await replyOrFollowUp(interaction, 'An error occurred while closing the ticket. Please try again later.');
    }
}

async function deferIfNeeded(interaction) {
    if (!interaction.deferred && !interaction.replied) {
        await interaction.deferReply({ ephemeral: true });
    }
}

async function replyOrFollowUp(interaction, message) {
    if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: message, ephemeral: true });
    } else {
        await interaction.followUp({ content: message, ephemeral: true });
    }
}

function sanitizeFileName(fileName) {
    return fileName.replace(/[<>:"\/\\|?*\x00-\x1F]/g, '_');
}

async function sendDMEmbedAndTranscript(client, interaction, ticket, action, userMessages) {
    try {
        if (!userMessages) userMessages = new Map();

        const minMessages = parseInt(config.TicketTranscript.MinMessages, 10);

        if (userMessages.size < minMessages) {
            return;
        }

        let transcriptAttachment;
        const transcriptType = config.TicketTranscript.Type.toUpperCase();
        const savePath = config.TicketTranscript.SavePath;

        if (!fs.existsSync(savePath)) {
            fs.mkdirSync(savePath, { recursive: true });
        }

        const ticketTypeName = config.TicketTypes[ticket.ticketType].Name;
        const fileNameTemplate = config.TicketTranscript.Name || "{ticket-id}-{ticketType}-{user}";
        const fileName = sanitizeFileName(fileNameTemplate
            .replace("{ticket-id}", ticket.ticketId)
            .replace("{ticketType}", ticketTypeName)
            .replace("{user}", interaction.user.username));
        const filePath = path.join(savePath, `${fileName}.txt`);

        if (transcriptType === "TXT") {
            const transcript = Array.from(userMessages.values())
                .map(m => `${new Date(m.createdTimestamp).toLocaleString()} - ${m.author.tag}: ${m.content}`)
                .reverse()
                .join('\n');
            const transcriptContent = transcript.length > 0 ? transcript : "No messages in this ticket.";

            transcriptAttachment = new AttachmentBuilder(Buffer.from(transcriptContent), { name: path.basename(filePath) });

            if (config.TicketTranscript.Save) {
                fs.writeFileSync(filePath, transcriptContent);
            }
        }

        if (config.TicketSettings.Enabled) {
            await sendLog(client, interaction, ticket, userMessages, transcriptAttachment);
        }

        if (config.TicketClosureDM.Enabled) {
            await sendDM(client, interaction, ticket, userMessages, transcriptAttachment, transcriptType);
        }
    } catch (error) {
        console.error('Error in sendDMEmbedAndTranscript:', error);
    }
}

async function sendLog(client, interaction, ticket, userMessages, transcriptAttachment) {
    try {
        if (!config || !config.Logs || !config.Logs.Close || !config.Logs.Close.Embed) {
            console.error('Log Embed configuration is missing or improperly defined.');
            return;
        }

        const logEmbedConfig = config.Logs.Close.Embed;
        const logsChannelId = config.TicketSettings.LogsChannelID;

        if (!logsChannelId) {
            console.error('LogsChannelID is not defined in the configuration.');
            return;
        }

        const logsChannel = interaction.guild.channels.cache.get(logsChannelId);
        if (!logsChannel) {
            console.error(`No channel found with LogsChannelID: ${logsChannelId}`);
            return;
        }

        const ticketType = config.TicketTypes[ticket.ticketType];

        const replacements = {
            ticketId: ticket.ticketId,
            userId: ticket.userId,
            user: `<@${ticket.userId}>`,
            channelId: ticket.channelId,
            channelName: interaction.channel.name,
            ticketType: ticketType.Name,
            priority: ticket.priority || 'N/A',
            rating: 'No Rating Yet',
            review: ticket.review || 'No Review',
            messageCount: userMessages.size.toString(),
            createdAt: formatTimestamp(ticket.createdAt),
            closedAt: formatTimestamp(ticket.closedAt),
            claimedBy: ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'N/A',
            claimedAt: formatTimestamp(ticket.claimedAt),
            closeReason: ticket.closeReason || lang.NoReason,
            closedBy: `<@${interaction.user.id}>`,
            guild: interaction.guild.name
        };

        let logEmbed = new EmbedBuilder(logEmbedConfig);
        logEmbed = replacePlaceholdersInEmbed(logEmbed, replacements);

        const messageOptions = { embeds: [logEmbed] };

        const transcriptType = config.TicketTranscript.Type.toUpperCase();

        if (transcriptType === "WEB") {
            const baseURL = config.Dashboard.CallbackURL.replace(/\/auth\/discord\/callback$/, '');
            const webUrl = `${baseURL}/transcript/${ticket.ticketId}`;
            const webButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('View Transcript')
                        .setStyle(ButtonStyle.Link)
                        .setURL(webUrl)
                );
            messageOptions.components = [webButton];
        } else if (transcriptType === "TXT" && transcriptAttachment) {
            messageOptions.files = [transcriptAttachment];
        }

        const logMessage = await logsChannel.send(messageOptions);
        ticket.logMessageId = logMessage.id;
        await ticket.save();
    } catch (error) {
        console.error('Error sending log:', error);
    }
}

async function sendDM(client, interaction, ticket, userMessages, transcriptAttachment, transcriptType) {
    try {
        const dmEmbedConfig = config.TicketClosureDM.Embed;
        const ticketOwner = await client.users.fetch(ticket.userId);
        const ticketType = config.TicketTypes[ticket.ticketType];

        const replacements = {
            ticketId: ticket.ticketId,
            userId: ticket.userId,
            user: `<@${ticket.userId}>`,
            channelId: ticket.channelId,
            channelName: interaction.channel.name,
            ticketType: ticketType.Name,
            priority: ticket.priority || 'N/A',
            rating: 'No Rating Yet',
            review: ticket.review || 'No Review',
            messageCount: userMessages.size.toString(),
            createdAt: formatTimestamp(ticket.createdAt),
            closedAt: formatTimestamp(ticket.closedAt),
            claimedBy: ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'N/A',
            claimedAt: formatTimestamp(ticket.claimedAt),
            closeReason: ticket.closeReason || lang.NoReason,
            closedBy: `<@${interaction.user.id}>`,
            guild: interaction.guild.name
        };

        let dmEmbed = new EmbedBuilder(dmEmbedConfig);
        dmEmbed = replacePlaceholdersInEmbed(dmEmbed, replacements);

        const components = [];
        if (config.Reviews.Enabled) {
            const reviewOptions = Array.from({ length: 5 }, (_, i) => ({
                label: `${i + 1} ${config.Reviews.Text}`,
                value: `${i + 1}`,
                emoji: config.Reviews.Emoji
            }));

            const reviewSelect = new StringSelectMenuBuilder()
                .setCustomId(`review_${interaction.channel.id}`)
                .setPlaceholder(config.Reviews.Placeholder)
                .addOptions(reviewOptions);

            const reviewRow = new ActionRowBuilder().addComponents(reviewSelect);
            components.push(reviewRow);
        }

        const messageOptions = { embeds: [dmEmbed], components };

        if (transcriptType === "WEB" && config.TicketClosureDM.Transcript) {
            const baseURL = config.Dashboard.CallbackURL.replace(/\/auth\/discord\/callback$/, '');
            const webUrl = `${baseURL}/transcript/${ticket.ticketId}`;
            const webButton = new ButtonBuilder()
                .setLabel('View Transcript')
                .setStyle(ButtonStyle.Link)
                .setURL(webUrl);

            const webButtonRow = new ActionRowBuilder().addComponents(webButton);
            components.push(webButtonRow);
        } else if (transcriptAttachment && config.TicketClosureDM.Transcript) {
            messageOptions.files = [transcriptAttachment];
        }

        messageOptions.components = components;

        try {
            await ticketOwner.send(messageOptions);
        } catch (dmError) {
            if (dmError.code === 50007) {
                const serverMessage = `Could not send the ticket closure details via DM. Direct messages are disabled.`;
                await interaction.channel.send({ content: serverMessage });
            } else {
                console.error(`Could not send DM to user ${ticket.userId}:`, dmError);
            }
        }
    } catch (error) {
        console.error('Error sending DM:', error);
    }
}

function replacePlaceholders(text, replacements) {
    if (typeof text !== 'string') return text;
    for (const key in replacements) {
        text = text.replace(new RegExp(`{${key}}`, 'g'), replacements[key]);
    }
    return text;
}

function replacePlaceholdersInEmbed(embed, replacements) {
    const newEmbed = new EmbedBuilder();

    if (embed.data.title && embed.data.title !== "") {
        newEmbed.setTitle(replacePlaceholders(embed.data.title, replacements));
    }
    if (embed.data.description && embed.data.description !== "") {
        newEmbed.setDescription(replacePlaceholders(Array.isArray(embed.data.description) ? embed.data.description.join('\n') : embed.data.description, replacements));
    }
    if (embed.data.footer && embed.data.footer.text && embed.data.footer.text !== "") {
        const footerText = replacePlaceholders(embed.data.footer.text, replacements);
        const footerIconURL = embed.data.footer.icon ? replacePlaceholders(embed.data.footer.icon, replacements) : undefined;
        newEmbed.setFooter({ text: footerText, iconURL: footerIconURL });
    } else {
    }
    if (embed.data.author && embed.data.author.text && embed.data.author.text !== "") {
        const authorName = replacePlaceholders(embed.data.author.text, replacements);
        const authorIconURL = embed.data.author.icon ? replacePlaceholders(embed.data.author.icon, replacements) : undefined;
        newEmbed.setAuthor({ name: authorName, iconURL: authorIconURL });
    } else {
    }
    if (embed.data.fields && embed.data.fields.length > 0) {
        const filteredFields = embed.data.fields.filter(field => field.name !== "" && field.value !== "");
        filteredFields.forEach(field => {
            newEmbed.addFields({
                name: replacePlaceholders(field.name, replacements),
                value: replacePlaceholders(field.value, replacements),
                inline: field.inline || false
            });
        });
    }
    if (embed.data.color && typeof embed.data.color === 'string' && embed.data.color !== "") {
        newEmbed.setColor(parseInt(embed.data.color.replace('#', ''), 16));
    }
    if (embed.data.image && typeof embed.data.image === 'string' && embed.data.image !== "") {
        newEmbed.setImage(embed.data.image);
    }
    if (embed.data.thumbnail && typeof embed.data.thumbnail === 'string' && embed.data.thumbnail !== "") {
        newEmbed.setThumbnail(embed.data.thumbnail);
    }

    return newEmbed;
}

function formatTimestamp(timestamp) {
    return timestamp ? `<t:${Math.floor(new Date(timestamp).getTime() / 1000)}:f>` : 'N/A';
}

async function sendArchiveEmbed(interaction, uniqueId, userId, reason) {
    let ticketTypeKey;
    if (interaction.channel.topic) {
        const topicParts = interaction.channel.topic.split(" ");
        ticketTypeKey = topicParts[1];
    } else {
        console.error('Channel topic is undefined.');
        await interaction.channel.send('An error occurred: Channel topic is undefined.');
        return;
    }

    const ticketType = config.TicketTypes[ticketTypeKey];
    const archiveEmbedConfig = config.ArchiveDesign.Embed;
    const archiveEmbed = new EmbedBuilder();

    const placeholders = {
        user: interaction.user.username,
        userTag: `<@${interaction.user.id}>`,
        reason: reason || lang.NoReason,
    };

    if (archiveEmbedConfig.Title) {
        archiveEmbed.setTitle(replacePlaceholders(archiveEmbedConfig.Title, placeholders));
    }
    if (archiveEmbedConfig.Description) {
        const description = Array.isArray(archiveEmbedConfig.Description)
            ? archiveEmbedConfig.Description.join('\n')
            : archiveEmbedConfig.Description;
        archiveEmbed.setDescription(replacePlaceholders(description, placeholders));
    }
    if (archiveEmbedConfig.Color) {
        archiveEmbed.setColor(archiveEmbedConfig.Color);
    }
    if (archiveEmbedConfig.Footer && archiveEmbedConfig.Footer.Text) {
        archiveEmbed.setFooter({
            text: replacePlaceholders(archiveEmbedConfig.Footer.Text, placeholders),
            iconURL: archiveEmbedConfig.Footer.Icon || null
        });
    }
    if (archiveEmbedConfig.Image) {
        archiveEmbed.setImage(archiveEmbedConfig.Image);
    }
    if (archiveEmbedConfig.Thumbnail) {
        archiveEmbed.setThumbnail(archiveEmbedConfig.Thumbnail);
    }

    const archiveRow = new ActionRowBuilder();
    const buttons = Object.values(archiveEmbedConfig.Buttons);

    const styleMap = {
        "PRIMARY": ButtonStyle.Primary,
        "SECONDARY": ButtonStyle.Secondary,
        "SUCCESS": ButtonStyle.Success,
        "DANGER": ButtonStyle.Danger,
        "LINK": ButtonStyle.Link
    };

    buttons.forEach(button => {
        const buttonStyle = styleMap[button.Style.toUpperCase()];
        if (buttonStyle) {
            archiveRow.addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketarchive-${uniqueId}-${button.Type.toLowerCase()}`)
                    .setLabel(button.Name)
                    .setStyle(buttonStyle)
                    .setEmoji(button.Emoji)
            );
        }
    });

    await interaction.channel.send({ embeds: [archiveEmbed], components: [archiveRow] });
}

module.exports = async (client, interaction) => {
    try {
        if (interaction.isButton()) {
            await handleButtonInteraction(client, interaction);
        } else if (interaction.isStringSelectMenu()) {
            await handleSelectMenuInteraction(client, interaction);
        } else if (interaction.isModalSubmit()) {
            if (interaction.customId.startsWith('reviewWhy_')) {
                await handleReviewFeedbackModal(client, interaction);
            } else {
                await handleModalSubmitInteraction(client, interaction);
            }
        }
    } catch (error) {
        console.error('Error handling interaction:', error);
        await replyOrFollowUp(interaction, 'An error occurred while processing your interaction. Please try again later.');
    }
};

async function handleSelectMenuInteraction(client, interaction) {
    try {
        if (interaction.customId === 'ticketcreate') {
            await handleTicketCreate(client, interaction);

            const originalMessage = await interaction.channel.messages.fetch(interaction.message.id);
            const selectMenu = interaction.component;
            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('ticketcreate')
                    .setPlaceholder(lang.Tickets.TicketTypePlaceholder)
                    .addOptions(selectMenu.options.map(option => ({
                        label: option.label,
                        emoji: option.emoji,
                        value: option.value,
                        description: option.description,
                    })))
            );

            await originalMessage.edit({ components: [row] });
        } else if (interaction.customId.startsWith('review_')) {
            await handleReviewSelect(client, interaction);
        }
    } catch (error) {
        console.error('Error handling select menu interaction:', error);
    }
}

async function handleButtonInteraction(client, interaction) {
    const [action, uniqueId, subAction] = interaction.customId.split('-');

    switch (action) {
        case 'ticketcreate':
            await handleTicketCreate(client, interaction);
            break;
        case 'ticketdelete':
            await handleDeleteTicket(client, interaction, uniqueId);
            break;
        case 'ticketclose':
            await handleTicketClose(client, interaction, uniqueId);
            break;
        case 'ticketarchive':
            if (subAction === 'reopen') {
                await handleReopenTicket(client, interaction, uniqueId);
            } else if (subAction === 'delete') {
                await handleDeleteTicket(client, interaction, uniqueId);
            } else if (subAction === 'transcript') {
                await handleTranscriptTicket(client, interaction, uniqueId);
            } else {
                console.warn(`Unknown sub-action: ${subAction}`);
            }
            break;
        case 'ticketclaim':
            await handleTicketClaim(client, interaction, uniqueId);
            break;
        case 'ticketunclaim':
            await handleTicketUnclaim(client, interaction, uniqueId);
            break;
        default:
            break;
    }
}

function convertSimplePatternToRegex(simplePattern) {
    let regexPattern = simplePattern
        .replace(/\./g, '\\.')
        .replace(/\*/g, '.*');
    return new RegExp(`^${regexPattern}$`, 'i');
}

async function handleModalSubmitInteraction(client, interaction) {
    try {
        const [modalAction, ticketTypeKey] = interaction.customId.split('-');
        if (modalAction === 'ticketcreate') {
            const ticketType = config.TicketTypes[ticketTypeKey];
            let questions = [];
            let smartResponses = [];
            const sentResponses = new Set();

            if (Array.isArray(ticketType.Questions) && ticketType.Questions.length > 0) {
                for (const questionConfig of ticketType.Questions) {
                    const questionKey = Object.keys(questionConfig)[0];
                    const question = questionConfig[questionKey].Question;
                    const answer = interaction.fields.getTextInputValue(questionKey) || "N/A";

                    questions.push({ question, answer });

                    const response = await getSmartResponse(answer, interaction.member.roles.cache.map(role => role.id));
                    if (response && !sentResponses.has(response.content)) {
                        smartResponses.push(response);
                        if (response.type === 'TEXT') {
                            sentResponses.add(response.content);
                        } else if (response.type === 'EMBED') {
                            sentResponses.add(response.embed.description);
                        }
                    }
                }

                await createTicket(client, interaction, ticketTypeKey, questions, ticketType.Panel, smartResponses);
            } else {
                await createTicket(client, interaction, ticketTypeKey, [], ticketType.Panel, []);
            }
        }
    } catch (error) {
        console.error('Error handling modal submission:', error);
        if (!interaction.replied && !interaction.deferred) {
            await replyOrFollowUp(interaction, 'An error occurred while processing your modal submission. Please try again later.');
        } else if (interaction.deferred) {
            await interaction.followUp({ content: 'An error occurred while processing your modal submission. Please try again later.', ephemeral: true });
        }
    }
}

client.on('guildMemberUpdate', async (oldMember, newMember) => {
    try {
        const tickets = await Ticket.find({ status: 'open' });

        for (const ticket of tickets) {
            const ticketType = config.TicketTypes[ticket.ticketType];
            if (!ticketType) {
                continue;
            }

            const channel = await client.channels.fetch(ticket.channelId).catch(() => null);
            if (!channel || !channel.isThread()) {
                continue;
            }

            const oldRoles = oldMember.roles.cache.map(role => role.id);
            const newRoles = newMember.roles.cache.map(role => role.id);

            const hadSupportRole = ticketType.SupportRole.some(roleId => oldRoles.includes(roleId));
            const hasSupportRole = ticketType.SupportRole.some(roleId => newRoles.includes(roleId));

            if (!hasSupportRole && hadSupportRole) {
                await channel.members.remove(newMember.id).catch(error => console.error(`Error removing member: ${error}`));
            }

            if (hasSupportRole && !hadSupportRole) {
                await channel.members.add(newMember.id).catch(error => console.error(`Error adding member: ${error}`));
            }
        }
    } catch (error) {
        console.error('Error handling role update:', error);
    }
});


async function compressAndConvertToBase64(imageBuffer, contentType) {
    let compressedBuffer;

    switch (contentType) {
        case 'image/jpeg':
            compressedBuffer = await sharp(imageBuffer)
                .jpeg({ quality: 20 })
                .toBuffer();
            break;
        case 'image/png':
            compressedBuffer = await sharp(imageBuffer)
                .png({ compressionLevel: 10 })
                .toBuffer();
            break;
        case 'image/webp':
            compressedBuffer = await sharp(imageBuffer)
                .webp({ quality: 20 })
                .toBuffer();
            break;
        default:
            compressedBuffer = imageBuffer;
            break;
    }

    console.log('Original size:', imageBuffer.length);
    console.log('Compressed size:', compressedBuffer.length);

    return compressedBuffer.toString('base64');
}

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    try {
        const ticket = await Ticket.findOne({ channelId: message.channel.id });
        if (ticket) {
            const attachments = [];

            for (const attachment of message.attachments.values()) {
                const response = await axios.get(attachment.url, { responseType: 'arraybuffer' });
                const imageBuffer = Buffer.from(response.data, 'binary');

                const compressedBase64 = await compressAndConvertToBase64(imageBuffer, attachment.contentType);

                attachments.push({
                    base64: compressedBase64,
                    contentType: attachment.contentType,
                    name: attachment.name,
                    id: attachment.id,
                    timestamp: message.createdAt
                });
            }

            const newMessage = {
                author: message.author.tag,
                authorId: message.author.id,
                content: message.content,
                timestamp: message.createdAt,
                attachments: attachments
            };

            ticket.messages.push(newMessage);
            ticket.messageCount = (ticket.messageCount || 0) + 1;
            await ticket.save();

            if (ticket) {
                const memberRoles = message.member.roles.cache.map(role => role.id);
                const response = await getSmartResponse(message.content, memberRoles);
                if (response) {
                    if (response.type === 'TEXT') {
                        await message.reply(response.content);
                    } else if (response.type === 'EMBED') {
                        await message.reply({ embeds: [response.embed] });
                    }
                }

                const autoAlertDuration = parseDuration(config.TicketTypes[ticket.ticketType].AutoAlert);
                if (autoAlertDuration > 0 && hasSupportRole(message.member, config.TicketTypes[ticket.ticketType].SupportRole)) {
                    const alertTime = new Date(Date.now() + autoAlertDuration);
                    ticket.alertTime = alertTime;
                    await ticket.save();
                }
            }
        }
    } catch (error) {
        console.error('Error updating ticket messages:', error);
    }
});

async function handleTicketCreate(client, interaction) {
    try {
        let ticketTypeKey;

        if (interaction.customId) {
            const parts = interaction.customId.split('-');
            ticketTypeKey = parts[1] ? parts[1] : interaction.values[0];
        } else {
            ticketTypeKey = interaction.values[0];
        }

        const ticketType = config.TicketTypes[ticketTypeKey];

        if (!ticketType) {
            console.error(`Ticket type for key "${ticketTypeKey}" not found in configuration.`);
            throw new Error('Ticket type not found.');
        }

        const blacklistedUser = await Blacklist.findOne({ userId: interaction.user.id });
        if (blacklistedUser) {
            const embedConfig = lang.Tickets.Blacklisted.Embed;
            const blacklistEmbed = new EmbedBuilder();

            if (embedConfig.Title) blacklistEmbed.setTitle(embedConfig.Title);
            if (embedConfig.Description && embedConfig.Description.length > 0) {
                blacklistEmbed.setDescription(embedConfig.Description.join('\n')
                    .replace('{user}', `<@${interaction.user.id}>`)
                    .replace('{reason}', blacklistedUser.reason)
                    .replace('{time}', `<t:${Math.floor(new Date(blacklistedUser.addedAt).getTime() / 1000)}:F>`));
            }
            if (embedConfig.Color) blacklistEmbed.setColor(embedConfig.Color);
            if (embedConfig.Footer && embedConfig.Footer.Text) {
                blacklistEmbed.setFooter({
                    text: embedConfig.Footer.Text || null,
                    iconURL: embedConfig.Footer.Icon || null
                });
            }
            if (embedConfig.Author && embedConfig.Author.Text) {
                blacklistEmbed.setAuthor({
                    name: embedConfig.Author.Text || null,
                    iconURL: embedConfig.Author.Icon || null
                });
            }
            if (embedConfig.Image) blacklistEmbed.setImage(embedConfig.Image);
            if (embedConfig.Thumbnail) blacklistEmbed.setThumbnail(embedConfig.Thumbnail);

            await interaction.reply({ embeds: [blacklistEmbed], ephemeral: true });
            return;
        }

        const userRoles = interaction.member.roles.cache.map(role => role.id);
        const hasValidRole = ticketType.UserRole.some(role => userRoles.includes(role));

        if (!hasValidRole) {
            await interaction.reply({ content: "You do not have the required roles to create this type of ticket.", ephemeral: true });
            return;
        }

        const existingTickets = await Ticket.find({
            userId: interaction.user.id,
            status: { $in: ['open', 'closed'] }
        });

        for (const ticket of existingTickets) {
            const channel = await client.channels.fetch(ticket.channelId).catch(() => null);
            if (!channel) {
                await Ticket.findOneAndUpdate(
                    { ticketId: ticket.ticketId },
                    { status: 'deleted', deletedAt: new Date() },
                    { new: true }
                );
            }
        }

        const updatedTickets = await Ticket.find({
            userId: interaction.user.id,
            status: { $in: ['open', 'closed'] }
        });

        if (updatedTickets.length >= config.TicketSettings.MaxTickets) {
            await interaction.reply({ content: lang.Tickets.AlreadyOpen, ephemeral: true });
            return;
        }

        const bypassRoles = config.WorkingHours.Bypass || [];
        const hasBypassRole = userRoles.some(role => bypassRoles.includes(role));

        if (config.WorkingHours && config.WorkingHours.Enabled) {
            const currentTime = moment().tz(config.WorkingHours.Timezone);
            const currentDay = currentTime.format('dddd');
            const workingHours = config.WorkingHours.Schedule[currentDay];

            if (workingHours) {
                const [start, end] = workingHours.split('-');
                const startTime = moment.tz(start, 'HH:mm', config.WorkingHours.Timezone);
                const endTime = moment.tz(end, 'HH:mm', config.WorkingHours.Timezone);

                if (!currentTime.isBetween(startTime, endTime) && !config.WorkingHours.allowOpenTickets && !hasBypassRole) {
                    const workingHoursMessage = lang.Tickets.WorkingHours
                        .replace('{workinghours_start}', `<t:${startTime.unix()}:t>`)
                        .replace('{workinghours_end}', `<t:${endTime.unix()}:t>`);
                    await interaction.reply({ content: workingHoursMessage, ephemeral: true });
                    return;
                }
            }
        }

        if (Array.isArray(ticketType.Questions) && ticketType.Questions.length > 0) {
            const modal = new ModalBuilder()
                .setCustomId(`ticketcreate-${ticketTypeKey}`)
                .setTitle(ticketType.Name || 'Create a Ticket');

            ticketType.Questions.forEach(question => {
                const questionKey = Object.keys(question)[0];
                const questionConfig = question[questionKey];

                const styleMap = {
                    Short: TextInputStyle.Short,
                    Paragraph: TextInputStyle.Paragraph
                };

                const input = new TextInputBuilder()
                    .setCustomId(questionKey)
                    .setLabel(questionConfig.Question || '')
                    .setPlaceholder(questionConfig.Placeholder || '')
                    .setStyle(styleMap[questionConfig.Style] || TextInputStyle.Short)
                    .setRequired(questionConfig.Required || false)
                    .setMaxLength(questionConfig.maxLength || 1000);

                const actionRow = new ActionRowBuilder().addComponents(input);
                modal.addComponents(actionRow);
            });

            await interaction.showModal(modal);
        } else {
            if (!interaction.deferred && !interaction.replied) {
                await interaction.deferReply({ ephemeral: true });
            }
            await createTicket(client, interaction, ticketTypeKey, [], ticketType.Panel);
        }
    } catch (error) {
        console.error('Error creating ticket:', error);

        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: 'An error occurred while creating the ticket. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending reply:', e));
        } else {
            await interaction.followUp({ content: 'An error occurred while creating the ticket. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending follow-up:', e));
        }
    }
}

async function getUserPriority(member) {
    const priorityConfig = config.Priority;
    if (!priorityConfig.Enabled) {
        return priorityConfig.DefaultPriority;
    }

    for (const level of Object.keys(priorityConfig.Levels)) {
        const levelConfig = priorityConfig.Levels[level];
        for (const roleId of levelConfig.Roles) {
            if (member.roles.cache.has(roleId)) {
                return level;
            }
        }
    }

    return priorityConfig.DefaultPriority;
}

async function handleTicketClaim(client, interaction) {
    const [action, ticketId] = interaction.customId.split('-');

    const ticket = await Ticket.findOne({ ticketId: ticketId });
    if (!ticket) {
        await interaction.reply({ content: 'Ticket not found.', ephemeral: true });
        return;
    }

    const ticketType = config.TicketTypes[ticket.ticketType];
    if (!ticketType.Claiming) {
        await interaction.reply({ content: 'Claiming is disabled for this ticket type.', ephemeral: true });
        return;
    }

    const userRoles = interaction.member.roles.cache.map(role => role.id);
    const hasSupportRole = ticketType.SupportRole.some(role => userRoles.includes(role));

    if (!hasSupportRole) {
        await interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
        return;
    }

    const message = await interaction.channel.messages.fetch(ticket.messageId);

    if (action === 'ticketclaim') {
        if (ticket.claimedBy) {
            await interaction.reply({ content: 'This ticket has already been claimed.', ephemeral: true });
            return;
        }

        ticket.claimedBy = interaction.user.id;
        ticket.claimedAt = new Date();
        await ticket.save();

        const embedMessage = message.embeds[0];
        const updatedEmbed = EmbedBuilder.from(embedMessage)
            .setFooter({ text: `Claimed by ${interaction.user.tag}` });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketclose-${ticketId}`)
                    .setLabel(lang.Tickets.CloseTicketButton)
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId(`ticketunclaim-${ticketId}`)
                    .setLabel('Unclaim')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`claimed-${ticketId}`)
                    .setLabel(`Claimed by ${interaction.user.tag}`)
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true)
            );

        await interaction.update({ embeds: [updatedEmbed], components: [row] });
        await interaction.followUp({ content: `You have claimed the ticket.`, ephemeral: true });

    } else if (action === 'ticketunclaim') {
        if (ticket.claimedBy !== interaction.user.id) {
            await interaction.reply({ content: 'You can only unclaim tickets you have claimed.', ephemeral: true });
            return;
        }

        ticket.claimedBy = null;
        ticket.claimedAt = null;
        await ticket.save();

        const embedMessage = message.embeds[0];
        const updatedEmbed = EmbedBuilder.from(embedMessage)
            .setFooter(null);

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketclose-${ticketId}`)
                    .setLabel(lang.Tickets.CloseTicketButton)
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒')
            );

        if (ticketType.Claiming) {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketclaim-${ticketId}`)
                    .setLabel('Claim')
                    .setStyle(ButtonStyle.Primary)
            );
        }

        await interaction.update({ embeds: [updatedEmbed], components: [row] });
        await interaction.followUp({ content: `You have unclaimed the ticket.`, ephemeral: true });
    }
}

async function handleTicketUnclaim(client, interaction, uniqueId) {
    try {
        const ticket = await Ticket.findOne({ ticketId: uniqueId });
        if (!ticket) {
            await interaction.reply({ content: 'Ticket not found.', ephemeral: true });
            return;
        }

        if (ticket.claimedBy !== interaction.user.id) {
            await interaction.reply({ content: 'You can only unclaim tickets you have claimed.', ephemeral: true });
            return;
        }

        ticket.claimedBy = null;
        await ticket.save();

        const channel = await client.channels.fetch(ticket.channelId);
        if (!channel) {
            await interaction.reply({ content: 'Channel not found.', ephemeral: true });
            return;
        }

        const message = await channel.messages.fetch(ticket.messageId);
        if (!message) {
            await interaction.reply({ content: 'Message not found.', ephemeral: true });
            return;
        }

        const embed = message.embeds[0];
        if (!embed) {
            await interaction.reply({ content: 'Embed not found.', ephemeral: true });
            return;
        }

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketclose-${uniqueId}`)
                    .setLabel(lang.Tickets.CloseTicketButton)
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒')
            );

        const ticketType = config.TicketTypes[ticket.ticketType];
        if (ticketType.Claiming) {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketclaim-${uniqueId}`)
                    .setLabel('Claim')
                    .setStyle(ButtonStyle.Primary)
            );
        }

        await message.edit({ embeds: [embed], components: [row] });
        await interaction.reply({ content: 'Ticket unclaimed successfully.', ephemeral: true });
    } catch (error) {
        console.error('Error unclaiming ticket:', error);
        await interaction.reply({ content: 'An error occurred while unclaiming the ticket. Please try again later.', ephemeral: true });
    }
}

async function sendFollowupMessage(ticketCreationMessage, ticketTypeKey, placeholders) {
    const followupConfig = config.TicketCreation[ticketTypeKey]?.Followup || config.TicketCreation.Default.Followup;

    if (followupConfig.Message && followupConfig.Message !== "") {
        const followupMessage = replacePlaceholders(followupConfig.Message, placeholders);
        await ticketCreationMessage.reply(followupMessage);
    }
}

async function createTicket(client, interaction, ticketTypeKey, questions, selectedPanel, smartResponses = []) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

        const ticketType = config.TicketTypes[ticketTypeKey];
        const member = interaction.member;
        const userPriority = await getUserPriority(member);

        const newTicketId = await generateUniqueTicketId();

        const ticketName = ticketType.ChannelName.replace('{ticket-id}', newTicketId)
            .replace('{user}', interaction.user.username)
            .replace('{priority}', userPriority);
        const existingChannel = interaction.guild.channels.cache.find(ch => ch.name === ticketName);

        if (existingChannel) {
            await interaction.followUp({ content: lang.Tickets.AlreadyOpen, ephemeral: true });
            return;
        }

        let permissionOverwriteArray = [
            {
                id: interaction.member.id,
                allow: ['SendMessages', 'ViewChannel', 'AttachFiles', 'EmbedLinks', 'ReadMessageHistory']
            },
            {
                id: interaction.guild.id,
                deny: ['SendMessages', 'ViewChannel']
            },
            {
                id: client.user.id,
                allow: ['SendMessages', 'ViewChannel']
            }
        ];

        ticketType.SupportRole.forEach(roleid => {
            let role = interaction.guild.roles.cache.get(roleid);
            if (role) {
                let tempArray = {
                    id: role.id,
                    allow: ['SendMessages', 'ViewChannel', 'AttachFiles', 'EmbedLinks', 'ReadMessageHistory']
                };
                permissionOverwriteArray.push(tempArray);
            }
        });

        ticketType.ViewOnly.forEach(roleid => {
            let role = interaction.guild.roles.cache.get(roleid);
            if (role) {
                let tempArray = {
                    id: role.id,
                    allow: ['ViewChannel', 'ReadMessageHistory'],
                    deny: ['SendMessages', 'AttachFiles', 'EmbedLinks']
                };
                permissionOverwriteArray.push(tempArray);
            }
        });

        let channel;
        if (config.TicketSettings.useThreads && ticketType.ChannelID) {
            const parentChannel = await client.channels.fetch(ticketType.ChannelID);
            if (!parentChannel || parentChannel.type !== ChannelType.GuildText) {
                await interaction.followUp({ content: 'Invalid parent channel for threads.', ephemeral: true });
                return;
            }

            channel = await parentChannel.threads.create({
                name: ticketName,
                autoArchiveDuration: ThreadAutoArchiveDuration.OneDay,
                reason: `Ticket ${newTicketId} created`,
                type: ChannelType.PrivateThread
            });

        } else {
            const channelOptions = {
                name: ticketName,
                type: ChannelType.GuildText,
                permissionOverwrites: permissionOverwriteArray
            };

            if (ticketType.CategoryID) {
                channelOptions.parent = ticketType.CategoryID;
            }

            channel = await interaction.guild.channels.create(channelOptions);

            const channelTopic = ticketType.ChannelTopic.replace('{userid}', `<@!${interaction.user.id}>`)
                .replace('{priority}', userPriority);
            await channel.setTopic(channelTopic);
        }

        const embedConfig = lang.Tickets.TicketCreated.Embed;
        const embed = new EmbedBuilder();

        if (embedConfig.Title) embed.setTitle(embedConfig.Title);
        if (embedConfig.Description && embedConfig.Description.length > 0) {
            embed.setDescription(embedConfig.Description.join('\n')
                .replace('{link}', `[${lang.Tickets.TicketCreated.LinkText}](https://discord.com/channels/${interaction.guild.id}/${channel.id})`));
        }
        if (embedConfig.Color) embed.setColor(embedConfig.Color);
        if (embedConfig.Footer && embedConfig.Footer.Text) {
            if (embedConfig.Footer.Text !== "") {
                embed.setFooter({
                    text: embedConfig.Footer.Text,
                    iconURL: embedConfig.Footer.Icon || null
                });
            }
        }
        if (embedConfig.Author && embedConfig.Author.Text) {
            if (embedConfig.Author.Text !== "") {
                embed.setAuthor({
                    name: embedConfig.Author.Text,
                    iconURL: embedConfig.Author.Icon || null
                });
            }
        }
        if (embedConfig.Image) embed.setImage(embedConfig.Image);
        if (embedConfig.Thumbnail) embed.setThumbnail(embedConfig.Thumbnail);

        const buttonConfig = lang.Tickets.TicketCreated.Button;
        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel(buttonConfig.Text)
                    .setStyle(ButtonStyle.Link)
                    .setURL(`https://discord.com/channels/${interaction.guild.id}/${channel.id}`)
                    .setEmoji(buttonConfig.Emoji || null)
            );

        await interaction.followUp({ embeds: [embed], components: [button], ephemeral: true });

        const placeholders = {
            ticketType: ticketType.Name,
            user: `<@${interaction.user.id}>`,
            guild: interaction.guild.name
        };

        const ticketCreationConfig = config.TicketCreation[ticketTypeKey] || config.TicketCreation.Default;

        const embedMessage = new EmbedBuilder()
            .setTitle(replacePlaceholders(ticketCreationConfig.Embed.Title, placeholders))
            .setDescription((ticketCreationConfig.Embed.Description || []).map(line => replacePlaceholders(line, placeholders)).join('\n'))
            .setColor(ticketCreationConfig.Embed.Color);

        if (ticketCreationConfig.Embed.Footer && ticketCreationConfig.Embed.Footer.Text) {
            if (ticketCreationConfig.Embed.Footer.Text !== "") {
                embedMessage.setFooter({
                    text: replacePlaceholders(ticketCreationConfig.Embed.Footer.Text, placeholders),
                    iconURL: replacePlaceholders(ticketCreationConfig.Embed.Footer.Icon || '', placeholders)
                });
            }
        }
        if (ticketCreationConfig.Embed.Author && ticketCreationConfig.Embed.Author.Text) {
            if (ticketCreationConfig.Embed.Author.Text !== "") {
                embedMessage.setAuthor({
                    name: replacePlaceholders(ticketCreationConfig.Embed.Author.Text, placeholders),
                    iconURL: replacePlaceholders(ticketCreationConfig.Embed.Author.Icon || '', placeholders)
                });
            }
        }
        if (ticketCreationConfig.Embed.Image) embedMessage.setImage(replacePlaceholders(ticketCreationConfig.Embed.Image, placeholders));
        if (ticketCreationConfig.Embed.Thumbnail) embedMessage.setThumbnail(replacePlaceholders(ticketCreationConfig.Embed.Thumbnail, placeholders));

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketclose-${newTicketId}`)
                    .setLabel(lang.Tickets.CloseTicketButton)
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒')
            );

        if (ticketType.Claiming) {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticketclaim-${newTicketId}`)
                    .setLabel('Claim')
                    .setStyle(ButtonStyle.Primary)
            );
        }

        const ticketCreationMessage = await channel.send({ embeds: [embedMessage], components: [row] });

        if (config.WorkingHours.Enabled) {
            const currentTime = moment().tz(config.WorkingHours.Timezone);
            const currentDay = currentTime.format('dddd');
            const workingHours = config.WorkingHours.Schedule[currentDay];

            if (workingHours) {
                const [start, end] = workingHours.split('-');
                const startTime = moment.tz(start, 'HH:mm', config.WorkingHours.Timezone);
                const endTime = moment.tz(end, 'HH:mm', config.WorkingHours.Timezone);

                if (!currentTime.isBetween(startTime, endTime)) {
                    const workingEmbedConfig = config.WorkingEmbed.Embed;
                    const workingEmbed = new EmbedBuilder();

                    if (workingEmbedConfig.Title) workingEmbed.setTitle(workingEmbedConfig.Title);
                    if (workingEmbedConfig.Description) {
                        const startTimestamp = `<t:${startTime.unix()}:t>`;
                        const endTimestamp = `<t:${endTime.unix()}:t>`;
                        workingEmbed.setDescription(workingEmbedConfig.Description.join('\n').replace('{workinghours_start}', startTimestamp).replace('{workinghours_end}', endTimestamp));
                    }
                    if (workingEmbedConfig.Color) workingEmbed.setColor(workingEmbedConfig.Color);
                    if (workingEmbedConfig.Footer && workingEmbedConfig.Footer.Text) {
                        if (workingEmbedConfig.Footer.Text !== "") {
                            workingEmbed.setFooter({ text: workingEmbedConfig.Footer.Text, iconURL: workingEmbedConfig.Footer.Icon || null });
                        }
                    }
                    if (workingEmbedConfig.Image) workingEmbed.setImage(workingEmbedConfig.Image);
                    if (workingEmbedConfig.Thumbnail) workingEmbed.setThumbnail(workingEmbedConfig.Thumbnail);

                    await channel.send({ embeds: [workingEmbed] });
                }
            }
        }

        if (config.QuestionDesign && config.QuestionDesign.Embed) {
            const questionDescriptions = questions.map(q =>
                config.QuestionDesign.Embed.Description[0].replace('{question}', q.question) +
                config.QuestionDesign.Embed.Description[1].replace('{answer}', q.answer)
            );

            if (questionDescriptions.length > 0) {
                const questionEmbedConfig = config.QuestionDesign.Embed;
                const questionEmbed = new EmbedBuilder()
                    .setDescription(questionDescriptions.join('\n'));

                if (questionEmbedConfig.Title) questionEmbed.setTitle(questionEmbedConfig.Title.replace('{ticketType}', ticketType.Name));
                if (questionEmbedConfig.Color) questionEmbed.setColor(questionEmbedConfig.Color);
                if (questionEmbedConfig.Footer && questionEmbedConfig.Footer.Text) {
                    if (questionEmbedConfig.Footer.Text !== "") {
                        questionEmbed.setFooter({ text: questionEmbedConfig.Footer.Text, iconURL: questionEmbedConfig.Footer.Icon || null });
                    }
                }
                if (questionEmbedConfig.Image) questionEmbed.setImage(questionEmbedConfig.Image);
                if (questionEmbedConfig.Thumbnail) questionEmbed.setThumbnail(questionEmbedConfig.Thumbnail);

                const questionMessage = await channel.send({ embeds: [questionEmbed] });

                for (const response of smartResponses) {
                    if (response.type === 'TEXT') {
                        await questionMessage.reply(response.content);
                    } else if (response.type === 'EMBED') {
                        await questionMessage.reply({ embeds: [response.embed] });
                    }
                }
            }
        }

        if (ticketType.TagSupport || ticketType.TagCreator) {
            let tagMessageContent = '';
            if (ticketType.TagSupport) {
                const supportTags = ticketType.SupportRole
                    .map(roleId => interaction.guild.roles.cache.has(roleId) ? `<@&${roleId}>` : null)
                    .filter(Boolean)
                    .join(' ');
                tagMessageContent += supportTags;
            }
            if (ticketType.TagCreator) {
                tagMessageContent += ` <@${interaction.user.id}>`;
            }
            if (tagMessageContent) {
                const tagMessage = await channel.send({ content: tagMessageContent.trim() });
                await tagMessage.delete();
            }
        }

        const ticket = new Ticket({
            ticketId: newTicketId,
            userId: interaction.user.id,
            channelId: channel.id,
            channelName: channel.name,
            guildId: interaction.guild.id,
            ticketType: ticketTypeKey,
            priority: userPriority,
            questions: questions,
            messageCount: 0,
            alertTime: null,
            messageId: ticketCreationMessage.id
        });

        await ticket.save();

        await sendFollowupMessage(ticketCreationMessage, ticketTypeKey, placeholders);

    } catch (error) {
        console.error('Error creating ticket:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.deferReply({ ephemeral: true });
        }
        await interaction.followUp({ content: 'An error occurred while creating the ticket. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending follow-up:', e));
    }
}


async function handleModalSubmitInteraction(client, interaction) {
    try {
        const [modalAction, ticketTypeKey] = interaction.customId.split('-');
        if (modalAction === 'ticketcreate') {
            const ticketType = config.TicketTypes[ticketTypeKey];
            let questions = [];
            let smartResponses = [];
            const sentResponses = new Set();

            if (Array.isArray(ticketType.Questions) && ticketType.Questions.length > 0) {
                for (const questionConfig of ticketType.Questions) {
                    const questionKey = Object.keys(questionConfig)[0];
                    const question = questionConfig[questionKey].Question;
                    const answer = interaction.fields.getTextInputValue(questionKey) || "N/A";

                    questions.push({ question, answer });

                    const response = await getSmartResponse(answer, interaction.member.roles.cache.map(role => role.id));
                    if (response && !sentResponses.has(response.content)) {
                        smartResponses.push(response);
                        if (response.type === 'TEXT') {
                            sentResponses.add(response.content);
                        } else if (response.type === 'EMBED') {
                            sentResponses.add(response.embed.description);
                        }
                    }
                }

                await createTicket(client, interaction, ticketTypeKey, questions, ticketType.Panel, smartResponses);
            } else {
                await createTicket(client, interaction, ticketTypeKey, [], ticketType.Panel, []);
            }
        }
    } catch (error) {
        console.error('Error handling modal submission:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.deferReply({ ephemeral: true });
        }
        await interaction.followUp({ content: 'An error occurred while processing your modal submission. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending follow-up:', e));
    }
}


async function generateUniqueTicketId() {
    const lastTicket = await Ticket.findOne().sort({ ticketId: -1 });
    const newTicketId = lastTicket ? lastTicket.ticketId + 1 : 1;

    let isUnique = false;
    while (!isUnique) {
        const existingTicket = await Ticket.findOne({ ticketId: newTicketId });
        if (existingTicket) {
            newTicketId++;
        } else {
            isUnique = true;
        }
    }

    return newTicketId;
}

async function handleReviewSelect(client, interaction) {
    try {
        const [_, channelId] = interaction.customId.split('_');
        if (!channelId) {
            throw new Error('No channelId found in the customId.');
        }

        const ticket = await Ticket.findOne({ channelId: channelId });
        if (ticket && ticket.rating !== 'No Rating Yet') {
            await interaction.reply({ content: lang.Tickets.ReviewAlreadySubmitted, ephemeral: true });
            return;
        }

        const rating = parseInt(interaction.values[0]);
        const ratingEmoji = config.Reviews.Emoji;
        const ratingString = `${ratingEmoji.repeat(rating)} (${rating}/5)`;

        if (config.Reviews.askWhy) {
            const modal = new ModalBuilder()
                .setCustomId(`reviewWhy_${channelId}_${rating}`)
                .setTitle(lang.Tickets.ReviewTitle)
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('reviewFeedback')
                            .setLabel(lang.Tickets.ReviewPlaceholder)
                            .setStyle(TextInputStyle.Paragraph)
                            .setRequired(true)
                    )
                );

            await interaction.showModal(modal);
        } else {
            await updateReview(channelId, ratingString, interaction);
        }
    } catch (error) {
        console.error('Error handling review select:', error);
        await interaction.reply({ content: 'An error occurred while submitting your review. Please try again later.', ephemeral: true });
    }
}

async function handleReviewFeedbackModal(client, interaction) {
    try {
        const parts = interaction.customId.split('_');
        if (parts.length < 3) {
            throw new Error('Invalid customId format. Expected at least 3 parts.');
        }

        const channelId = parts[1];
        const rating = parts[2];
        if (!channelId || !rating) {
            throw new Error('Missing channelId or rating in the customId.');
        }

        const feedback = interaction.fields.getTextInputValue('reviewFeedback');
        if (!feedback) {
            throw new Error('Review feedback is missing.');
        }

        const ratingEmoji = config.Reviews.Emoji;
        const ratingString = `${ratingEmoji.repeat(rating)} (${rating}/5)`;

        const updatedTicket = await Ticket.findOneAndUpdate(
            { channelId: channelId },
            { rating: ratingString, reviewFeedback: feedback },
            { new: true }
        );

        if (!updatedTicket) {
            await interaction.reply({ content: 'Ticket not found or already closed.', ephemeral: true });
            return;
        }

        const logsChannel = client.channels.cache.get(config.TicketSettings.LogsChannelID);
        if (!logsChannel) {
            console.error('Logs channel not found.');
            await interaction.reply({ content: 'Could not find the logs channel. Please try again later.', ephemeral: true });
            return;
        }

        let logMessage;
        try {
            logMessage = await logsChannel.messages.fetch(updatedTicket.logMessageId);
        } catch (fetchError) {
            console.error('Log message not found:', fetchError);
            await interaction.reply({ content: 'Could not find the log message. Please try again later.', ephemeral: true });
            return;
        }

        if (!logMessage || !logMessage.embeds.length) {
            console.error('Log embed not found or empty.');
            await interaction.reply({ content: 'Could not find the log embed. Please try again later.', ephemeral: true });
            return;
        }

        const logEmbed = logMessage.embeds[0];

        const replacements = {
            ticketId: updatedTicket.ticketId,
            userId: updatedTicket.userId,
            user: `<@${updatedTicket.userId}>`,
            channelId: updatedTicket.channelId,
            channelName: updatedTicket.channelName,
            ticketType: config.TicketTypes[updatedTicket.ticketType]?.Name || updatedTicket.ticketType,
            priority: updatedTicket.priority || 'N/A',
            rating: `${ratingString}\nReview: ${feedback}`,
            review: updatedTicket.review || 'No Review',
            messageCount: updatedTicket.messageCount.toString(),
            createdAt: formatTimestamp(updatedTicket.createdAt),
            closedAt: formatTimestamp(updatedTicket.closedAt),
            claimedBy: updatedTicket.claimedBy ? `<@${updatedTicket.claimedBy}>` : 'N/A',
            claimedAt: formatTimestamp(updatedTicket.claimedAt),
            closeReason: updatedTicket.closeReason || lang.NoReason,
            closedBy: `<@${interaction.user.id}>`
        };

        const updatedDescription = config.Logs.Close.Embed.Description.map(line =>
            replacePlaceholders(line, replacements)
        ).join('\n');

        const updatedEmbed = EmbedBuilder.from(logEmbed).setDescription(updatedDescription);

        await logMessage.edit({ embeds: [updatedEmbed] });

        await interaction.reply({ content: lang.Tickets.ReviewComplete, ephemeral: true });
    } catch (error) {
        console.error('Error handling review feedback modal:', error);
        await interaction.reply({ content: `An error occurred: ${error.message}. Please try again later.`, ephemeral: true });
    }
}

async function updateReview(channelId, ratingString, interaction) {
    const updatedTicket = await Ticket.findOneAndUpdate(
        { channelId: channelId },
        { rating: ratingString },
        { new: true }
    );

    if (!updatedTicket) {
        await interaction.reply({ content: 'Ticket not found or already closed.', ephemeral: true });
        return;
    }

    const logsChannel = client.channels.cache.get(config.TicketSettings.LogsChannelID);
    if (!logsChannel) {
        console.error('Logs channel not found.');
        await interaction.reply({ content: 'Could not find the logs channel. Please try again later.', ephemeral: true });
        return;
    }

    const logMessage = await logsChannel.messages.fetch(updatedTicket.logMessageId);
    if (!logMessage) {
        console.error('Log message not found.');
        await interaction.reply({ content: 'Could not find the log message. Please try again later.', ephemeral: true });
        return;
    }

    const logEmbed = logMessage.embeds[0];
    if (!logEmbed) {
        console.error('Log embed not found.');
        await interaction.reply({ content: 'Could not find the log embed. Please try again later.', ephemeral: true });
        return;
    }

    const replacements = {
        ticketId: updatedTicket.ticketId,
        userId: updatedTicket.userId,
        user: `<@${updatedTicket.userId}>`,
        channelId: updatedTicket.channelId,
        channelName: updatedTicket.channelName,
        ticketType: config.TicketTypes[updatedTicket.ticketType]?.Name || updatedTicket.ticketType,
        priority: updatedTicket.priority || 'N/A',
        rating: `${ratingString}\nReview: No additional feedback provided.`,
        review: updatedTicket.review || 'No Review',
        messageCount: updatedTicket.messageCount.toString(),
        createdAt: formatTimestamp(updatedTicket.createdAt),
        closedAt: formatTimestamp(updatedTicket.closedAt),
        claimedBy: updatedTicket.claimedBy ? `<@${updatedTicket.claimedBy}>` : 'N/A',
        claimedAt: formatTimestamp(updatedTicket.claimedAt),
        closeReason: updatedTicket.closeReason || lang.NoReason,
        closedBy: `<@${interaction.user.id}>`
    };

    const updatedDescription = config.Logs.Close.Embed.Description.map(line =>
        replacePlaceholders(line, replacements)
    ).join('\n');

    const updatedEmbed = EmbedBuilder.from(logEmbed).setDescription(updatedDescription);

    await logMessage.edit({ embeds: [updatedEmbed] });

    await interaction.reply({ content: lang.Tickets.ReviewComplete, ephemeral: true });
}

async function handleReopenTicket(client, interaction, uniqueId) {
    try {
        const ticket = await Ticket.findOneAndUpdate(
            { ticketId: uniqueId },
            { status: 'open', closedAt: null },
            { new: true }
        );

        if (!ticket) {
            console.error(`No ticket found in the database with ticketId: ${uniqueId}`);
            await interaction.reply({ content: 'Ticket not found.', ephemeral: true });
            return;
        }

        const channel = await client.channels.fetch(ticket.channelId);
        if (!channel) {
            console.error(`No channel found with channelId: ${ticket.channelId}`);
            await interaction.reply({ content: 'Channel not found.', ephemeral: true });
            return;
        }

        const ticketType = config.TicketTypes[ticket.ticketType];
        if (!ticketType) {
            console.error(`No ticket type found in the configuration for ticketType: ${ticket.ticketType}`);
            await interaction.reply({ content: 'Ticket type configuration not found.', ephemeral: true });
            return;
        }

        const messages = await channel.messages.fetch({ limit: 100 });
        const archiveEmbedMessage = messages.find(msg => msg.embeds.length > 0 && msg.embeds[0].title === 'Ticket Closed');
        if (archiveEmbedMessage) {
            await archiveEmbedMessage.delete();
        }

        await channel.setParent(ticketType.CategoryID);

        const permissionOverwrites = [
            {
                id: ticket.userId,
                allow: ['SendMessages', 'ViewChannel', 'AttachFiles', 'EmbedLinks', 'ReadMessageHistory']
            },
            {
                id: channel.guild.roles.everyone.id,
                deny: ['SendMessages', 'ViewChannel']
            },
            {
                id: client.user.id,
                allow: ['SendMessages', 'ViewChannel']
            }
        ];

        ticketType.SupportRole.forEach(roleid => {
            let role = channel.guild.roles.cache.get(roleid);
            if (role) {
                permissionOverwrites.push({
                    id: role.id,
                    allow: ['SendMessages', 'ViewChannel', 'AttachFiles', 'EmbedLinks', 'ReadMessageHistory']
                });
            } else {
                //   console.log(`[WARNING] Role ID ${roleid} SupportRole is not valid!`);
            }
        });

        await channel.permissionOverwrites.set(permissionOverwrites);

        const reopenEmbed = new EmbedBuilder()
            .setTitle(lang.Tickets.TicketReopenTitle)
            .setColor("Green")
            .setDescription(replacePlaceholders(lang.Tickets.TicketReopenDescription, { userId: interaction.user.id }))
            .setTimestamp();

        await channel.send({ embeds: [reopenEmbed] });
        await interaction.reply({ content: lang.Tickets.TicketReopen, ephemeral: true });
    } catch (error) {
        console.error('Error handling ticket reopening:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: 'An error occurred while reopening the ticket. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending reply:', e));
        } else {
            await interaction.followUp({ content: 'An error occurred while reopening the ticket. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending follow-up:', e));
        }
    }
}

async function handleTranscriptTicket(client, interaction, uniqueId) {
    try {
        const ticket = await Ticket.findOne({ ticketId: uniqueId });

        if (!ticket) {
            console.error(`No ticket found in the database with ticketId: ${uniqueId}`);
            await interaction.reply({ content: 'Ticket not found.', ephemeral: true });
            return;
        }

        const channel = await client.channels.fetch(ticket.channelId);
        if (!channel) {
            console.error(`No channel found with channelId: ${ticket.channelId}`);
            await interaction.reply({ content: 'Channel not found.', ephemeral: true });
            return;
        }

        const fetchedMessages = await channel.messages.fetch({ limit: 100 });
        const userMessages = fetchedMessages.filter(m => !m.author.bot);

        const minMessages = parseInt(config.TicketTranscript.MinMessages, 10);

        if (userMessages.size >= minMessages) {
            const transcript = userMessages
                .map(m => `${new Date(m.createdTimestamp).toLocaleString()} - ${m.author.tag}: ${m.content}`)
                .reverse()
                .join('\n');
            const transcriptContent = transcript.length > 0 ? transcript : "No messages in this ticket.";

            const transcriptType = config.TicketTranscript.Type.toUpperCase();
            let transcriptAttachment;
            let filePath;

            const savePath = config.TicketTranscript.SavePath;
            if (!fs.existsSync(savePath)) {
                fs.mkdirSync(savePath, { recursive: true });
            }

            const fileName = `${interaction.channel.name}-transcript.${transcriptType.toLowerCase()}`;
            filePath = getUniqueFilePath(path.join(savePath, fileName));

            if (transcriptType === "TXT") {
                transcriptAttachment = new AttachmentBuilder(Buffer.from(transcriptContent), { name: path.basename(filePath) });

                if (config.TicketTranscript.Save) {
                    fs.writeFileSync(filePath, transcriptContent);
                }
            }

            const logEmbed = new EmbedBuilder()
                .setTitle(lang.Tickets.TranscriptTitle)
                .setColor("Blue")
                .setDescription(replacePlaceholders(lang.Tickets.TranscriptDescription, { ticketId: uniqueId, userId: interaction.user.id }))
                .setTimestamp();

            if (transcriptType === "WEB") {
                const baseURL = config.TicketTranscript.WebServer.CallbackURL.replace(/\/auth\/discord\/callback$/, '');
                const webUrl = `${baseURL}/transcript/${ticket.ticketId}`;
                const webButton = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setLabel('View Transcript')
                            .setStyle(ButtonStyle.Link)
                            .setURL(webUrl)
                    );

                const webEmbed = new EmbedBuilder()
                    .setTitle(lang.Tickets.TranscriptTitle)
                    .setColor("Blue")
                    .setDescription(replacePlaceholders(lang.Tickets.TranscriptDescription, { ticketId: uniqueId, userId: interaction.user.id }))
                    .setTimestamp();

                await interaction.reply({ content: lang.Tickets.TranscriptTitle, ephemeral: true });

                const logsChannel = interaction.guild.channels.cache.get(config.TicketSettings.LogsChannelID);
                if (logsChannel) {
                    await logsChannel.send({ embeds: [webEmbed], components: [webButton] });
                }

                try {
                    await interaction.user.send({ embeds: [webEmbed], components: [webButton] });
                } catch (dmError) {
                    if (dmError.code === 50007) {
                        console.error('Could not send transcript to user\'s DM: Cannot send messages to this user');
                    } else {
                        console.error('Could not send DM to user:', dmError);
                    }
                }
            } else {
                await interaction.reply({ content: lang.Tickets.TranscriptTitle, ephemeral: true });

                const logsChannel = interaction.guild.channels.cache.get(config.TicketSettings.LogsChannelID);
                if (logsChannel) {
                    await logsChannel.send({ embeds: [logEmbed], files: [transcriptAttachment] });
                }

                try {
                    await interaction.user.send({ content: lang.Tickets.TranscriptReady, files: [transcriptAttachment] });
                } catch (dmError) {
                    if (dmError.code === 50007) {
                        console.error('Could not send transcript to user\'s DM: Cannot send messages to this user');
                    } else {
                        console.error('Could not send DM to user:', dmError);
                    }
                }
            }
        } else {
            await interaction.reply({ content: lang.Tickets.TranscriptNotEnough, ephemeral: true });
        }
    } catch (error) {
        console.error('Error handling transcript generation:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: 'An error occurred while generating the transcript. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending reply:', e));
        } else {
            await interaction.followUp({ content: 'An error occurred while generating the transcript. Please try again later.', ephemeral: true }).catch(e => console.error('Error sending follow-up:', e));
        }
    }
}

function getUniqueFilePath(filePath) {
    let uniquePath = filePath;
    let fileIndex = 1;

    while (fs.existsSync(uniquePath)) {
        const parsedPath = path.parse(filePath);
        uniquePath = path.join(parsedPath.dir, `${parsedPath.name}_${fileIndex}${parsedPath.ext}`);
        fileIndex++;
    }

    return uniquePath;
}

module.exports.handleDeleteTicket = handleDeleteTicket;
module.exports.handleTicketClose = handleTicketClose;
module.exports.sendDMEmbedAndTranscript = sendDMEmbedAndTranscript;