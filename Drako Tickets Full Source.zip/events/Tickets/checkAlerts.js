﻿const fs = require('fs');
const yaml = require('js-yaml');
const path = require('path');
const Ticket = require('../../models/tickets');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { handleTicketClose } = require('../interactionCreate');

let config;

try {
    const configPath = path.join(__dirname, '../../config.yml');
    config = yaml.load(fs.readFileSync(configPath, 'utf8'));
} catch (error) {
    console.error('Error loading configuration file:', error);
    process.exit(1);
}

async function checkAlerts(client) {
    const now = new Date();
    const ticketsToAlert = await Ticket.find({ status: 'open' });

    for (const ticket of ticketsToAlert) {
        const ticketType = config.TicketTypes[ticket.ticketType];
        const autoAlertDuration = ticketType.AutoAlert;

        if (autoAlertDuration && autoAlertDuration !== "0") {
            const alertDurationMs = parseDuration(autoAlertDuration);
            const lastResponseTime = ticket.lastResponseTime ? new Date(ticket.lastResponseTime) : new Date(ticket.createdAt);
            const alertTime = new Date(lastResponseTime.getTime() + alertDurationMs);

            if (now >= alertTime) {
                const channel = await client.channels.fetch(ticket.channelId).catch(() => null);
                if (channel) {
                    await triggerAlert(client, channel, ticket);
                } else {
                    console.debug(`Channel not found for ticket ID: ${ticket._id}`);
                }
            }
        }
    }
}

async function triggerAlert(client, channel, ticket) {
    const now = new Date();
    if (ticket.alertTime && now >= new Date(ticket.alertTime)) {
        const user = await client.users.fetch(ticket.userId).catch(error => {
            return null;
        });
        if (!user) return;

        const guild = channel.guild;
        const member = await guild.members.fetch(ticket.userId).catch(error => {
            return null;
        });
        if (!member) return;

        const mockInteraction = {
            client,
            channel,
            guild,
            user: { ...user, tag: '/alert' },
            member: member,
            options: {
                getString: (name) => {
                    if (name === 'reason') {
                        return 'Alert expired, auto-closing ticket.';
                    }
                    return null;
                }
            },
            replied: false,
            deferred: false,
            reply: async (message) => {
                await channel.send(message).catch(error => {
                    if (error.code === 10003) {
                        console.error(`Channel not found while trying to send message for ticket ID: ${ticket._id}`);
                    } else {
                        throw error;
                    }
                });
            },
            followUp: async (message) => {
                await channel.send(message).catch(error => {
                    if (error.code === 10003) {
                        console.error(`Channel not found while trying to send follow-up message for ticket ID: ${ticket._id}`);
                    } else {
                        throw error;
                    }
                });
            },
            deferUpdate: async () => { },
            deferReply: async () => { },
        };

        try {
            await handleTicketClose(client, mockInteraction, ticket.ticketId);
        } catch (error) {
            console.error(`Error closing ticket ID: ${ticket._id}`, error);
        }
        return;
    }

    if (ticket.waitingForUser) {
        return;
    }

    if (ticket.alertMessageId) {
        return;
    }

    const messages = await channel.messages.fetch({ limit: 1 });
    const lastMessage = messages.first();
    if (lastMessage && lastMessage.author.id === ticket.userId) {
        return;
    }

    const alertConfig = config.Alert.Embed;
    const alertDurationMs = parseDuration(config.Alert.Time);
    const futureTime = new Date(Date.now() + alertDurationMs);
    const discordTimestamp = `<t:${Math.floor(futureTime.getTime() / 1000)}:R>`;

    const alertEmbed = new EmbedBuilder()
        .setDescription(alertConfig.Description.join('\n').replace('{user}', `<@${ticket.userId}>`).replace('{time}', discordTimestamp));

    if (alertConfig.Title) alertEmbed.setTitle(alertConfig.Title);
    if (alertConfig.Color) alertEmbed.setColor(alertConfig.Color);
    if (alertConfig.Footer && alertConfig.Footer.Text) {
        alertEmbed.setFooter({ text: alertConfig.Footer.Text, iconURL: alertConfig.Footer.Icon || null });
    }
    if (alertConfig.Image) alertEmbed.setImage(alertConfig.Image);
    if (alertConfig.Thumbnail) alertEmbed.setThumbnail(alertConfig.Thumbnail);

    const closeButton = new ButtonBuilder()
        .setCustomId(`ticketclose-${ticket.ticketId}`)
        .setLabel('Close Ticket')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🔒');

    const actionRow = new ActionRowBuilder().addComponents(closeButton);

    const tagMessage = await channel.send(`<@${ticket.userId}>`);
    const alertMessage = await channel.send({ embeds: [alertEmbed], components: [actionRow] });
    setTimeout(() => tagMessage.delete(), 500);

    ticket.alertMessageId = alertMessage.id;
    ticket.alertTime = futureTime;
    await ticket.save();

    setTimeout(async () => {
        const updatedTicket = await Ticket.findOne({ _id: ticket._id });

        if (updatedTicket && updatedTicket.alertMessageId === alertMessage.id) {
            const user = await client.users.fetch(updatedTicket.userId).catch(error => {
                return null;
            });
            if (!user) return;

            const guild = channel.guild;
            const member = await guild.members.fetch(updatedTicket.userId).catch(error => {
                return null;
            });
            if (!member) return;

            const mockInteraction = {
                client,
                channel,
                guild,
                user: { ...user, tag: '/alert' },
                member: member,
                options: {
                    getString: (name) => {
                        if (name === 'reason') {
                            return 'Alert expired, auto-closing ticket.';
                        }
                        return null;
                    }
                },
                replied: false,
                deferred: false,
                reply: async (message) => {
                    await channel.send(message).catch(error => {
                        if (error.code === 10003) {
                            console.error(`Channel not found while trying to send message for ticket ID: ${updatedTicket._id}`);
                        } else {
                            throw error;
                        }
                    });
                },
                followUp: async (message) => {
                    await channel.send(message).catch(error => {
                        if (error.code === 10003) {
                            console.error(`Channel not found while trying to send follow-up message for ticket ID: ${updatedTicket._id}`);
                        } else {
                            throw error;
                        }
                    });
                },
                deferUpdate: async () => { },
                deferReply: async () => { },
            };

            try {
                await handleTicketClose(client, mockInteraction, updatedTicket.ticketId);
            } catch (error) {
                console.error(`Error closing ticket ID: ${updatedTicket._id}`, error);
            }
        }
    }, alertDurationMs);
}

function parseDuration(duration) {
    const timeUnits = {
        s: 1000,
        m: 1000 * 60,
        h: 1000 * 60 * 60,
        d: 1000 * 60 * 60 * 24,
        w: 1000 * 60 * 60 * 24 * 7
    };

    const matches = duration.match(/(\d+\s*[smhdw])/g);
    if (!matches) return 0;

    return matches.reduce((total, match) => {
        const value = parseInt(match.match(/\d+/)[0]);
        const unit = match.match(/[smhdw]/)[0];
        return total + value * timeUnits[unit];
    }, 0);
}

function startAlertScheduler(client) {
    if (config.Alert && config.Alert.Enabled) {
        setInterval(() => checkAlerts(client), 10 * 1000);
    } else {
    }
}

module.exports = { startAlertScheduler };