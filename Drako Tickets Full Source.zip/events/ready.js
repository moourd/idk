const { ActivityType } = require('discord.js');
const fs = require('fs');
const yaml = require("js-yaml");
const moment = require('moment-timezone');
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const colors = require('ansi-colors');
const cfonts = require('cfonts');
const packageFile = require('../package.json');
const GuildData = require('../models/guildDataSchema');
const Ticket = require('../models/tickets');

module.exports = async client => {
    if (packageFile.version !== config.Version) {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] Your config.yml file is outdated!`);
        process.exit();
    }

    let guild = client.guilds.cache.get(config.GuildID);
    if (!guild) {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] The guild ID specified in the config is invalid or the bot is not in the server!`);
        console.log(`Invite the bot using this link: https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot+applications.commands`);
        process.exit();
    }

    let guildData = await GuildData.findOne({ guildID: guild.id });
    if (!guildData) {
        guildData = new GuildData({
            guildID: guild.id,
            totalMessages: 0,
            timesBotStarted: 1
        });
        await guildData.save();
    } else {
        guildData.timesBotStarted++;
        await guildData.save();
    }

    function getUptime() {
        const duration = moment.duration(client.uptime);
        let uptimeString = '';

        const years = duration.years();
        const months = duration.months();
        const weeks = duration.weeks();
        const days = duration.days();
        const hours = duration.hours();
        const minutes = duration.minutes();
        const seconds = duration.seconds();

        if (years > 0) {
            uptimeString += `${years}y `;
        }

        if (years > 0 || months > 0) {
            uptimeString += `${months}mo `;
        }

        if ((years > 0 || months > 0 || weeks > 0) && !days) {
            uptimeString += `${weeks}w `;
        }

        if (years > 0 || months > 0 || weeks > 0 || days > 0) {
            uptimeString += `${days}d `;
        }
        uptimeString += `${hours}h ${minutes}m ${seconds}s`;

        return uptimeString;
    }

    async function getTicketStatistics() {
        const totalTickets = await Ticket.countDocuments({});
        const openTickets = await Ticket.countDocuments({ status: 'open' });
        const closedTickets = await Ticket.countDocuments({ status: 'closed' });
        const deletedTickets = await Ticket.countDocuments({ status: 'deleted' });
        return { totalTickets, openTickets, closedTickets, deletedTickets };
    }

    async function updateBotActivity(index) {
        try {
            const guild = client.guilds.cache.get(config.GuildID);
            if (!guild) {
                console.log(`Guild not found for ID plants}`);
                return;
            }

            let guildData = await GuildData.findOne({ guildID: guild.id });
            if (!guildData) {
                console.log(`Guild data not found for guild ID: ${guild.id}`);
                return;
            }

            if (index < 0 || index >= config.BotActivitySettings.Statuses.length) {
                console.log(`Invalid status index: ${index}`);
                return;
            }

            const totalChannels = guild.channels.cache.filter(channel =>
                channel.type === 'GUILD_TEXT' || channel.type === 'GUILD_VOICE'
            ).size;

            const onlineMembers = guild.members.cache.filter(member =>
                ['online', 'idle', 'dnd'].includes(member.presence?.status)
            ).size;

            const uptime = getUptime();
            const { totalTickets, openTickets, closedTickets, deletedTickets } = await getTicketStatistics();

            const activityString = config.BotActivitySettings.Statuses[index]
                .replace(/{total-users}/g, `${guild.memberCount}`)
                .replace(/{total-channels}/g, `${totalChannels}`)
                .replace(/{total-messages}/g, `${guildData.totalMessages}`)
                .replace(/{online-members}/g, `${onlineMembers}`)
                .replace(/{uptime}/g, `${uptime}`)
                .replace(/{total-boosts}/g, `${guild.premiumSubscriptionCount}`)
                .replace(/{times-bot-started}/g, `${guildData.timesBotStarted}`)
                .replace(/{total-tickets}/g, `${totalTickets}`)
                .replace(/{open-tickets}/g, `${openTickets}`)
                .replace(/{closed-tickets}/g, `${closedTickets}`)
                .replace(/{deleted-tickets}/g, `${deletedTickets}`);

            let activityType;
            switch (config.BotActivitySettings.ActivityType.toUpperCase()) {
                case "WATCHING":
                    activityType = ActivityType.Watching;
                    break;
                case "PLAYING":
                    activityType = ActivityType.Playing;
                    break;
                case "COMPETING":
                    activityType = ActivityType.Competing;
                    break;
                case "STREAMING":
                    activityType = ActivityType.Streaming;
                    break;
                case "CUSTOM":
                    activityType = ActivityType.Custom;
                    break;
                default:
                    console.log(`Invalid Activity Type: ${config.BotActivitySettings.ActivityType}`);
                    activityType = ActivityType.Custom;
            }

            const presenceOptions = {
                activities: [{ name: activityString, type: activityType }],
                status: config.BotActivitySettings.Status,
            };

            if (activityType === ActivityType.Streaming && config.BotActivitySettings.StreamingURL) {
                presenceOptions.activities[0].url = config.BotActivitySettings.StreamingURL;
            }

            await client.user.setPresence(presenceOptions);
        } catch (error) {
            console.error('Error updating bot activity:', error);
        }
    }

    if (config.BotActivitySettings.Enabled) {
        let index = 0;
        updateBotActivity(index);
        setInterval(() => {
            index = (index + 1) % config.BotActivitySettings.Statuses.length;
            updateBotActivity(index);
        }, config.BotActivitySettings.Interval * 1000);
    }

    client.guilds.cache.forEach(guild => {
        if (!config.GuildID.includes(guild.id)) {
            guild.leave();
            console.log('\x1b[31m%s\x1b[0m', `[INFO] Someone tried to invite the bot to another server! I automatically left it (${guild.name})`);
        }
    });

    if (guild && !guild.members.me.permissions.has("Administrator")) {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] The bot doesn't have enough permissions! Please give the bot ADMINISTRATOR permissions in your server or it won't function properly!`);
    }

    try {
        logStartupMessages(client);
    } catch (error) {
        console.error('An error occurred:', error);
    }
};

async function logStartupMessages(client) {
    try {
        const guild = client.guilds.cache.get(config.GuildID);
        const updatedGuildData = await GuildData.findOne({ guildID: guild.id });
        const totalTickets = await Ticket.countDocuments({});

        cfonts.say(`Drako Tickets\nv${packageFile.version}`, {
            font: 'block',
            align: 'left',
            background: 'transparent',
            letterSpacing: 1,
            lineHeight: 1,
            space: true,
            maxLength: '0',
            gradient: ['#4455dd', '#4455dd']
        });

        if (config.LicenseKey) {
            const formattedLicenseKey = config.LicenseKey.slice(0, 9) + '-XXXX-XXXX';
            console.log("   � License Key: " + (formattedLicenseKey));
        }

        console.log("   � Need support? " + colors.green("http://discord.drakodevelopment.net"));
        console.log("   � Terms of Service: " + colors.blue("https://docs.drakodevelopment.net/terms-and-conditions/"));
        console.log("   � Purchase Addons: " + colors.red("http://discord.drakodevelopment.net"));

        if (config.Statistics) {
            console.log("   � Bot Start Count: " + colors.cyan.underline(updatedGuildData.timesBotStarted.toLocaleString('en-US')));
            console.log("   � Total Messages Sent: " + colors.cyan.underline(updatedGuildData.totalMessages.toLocaleString('en-US')));
            console.log("   � Total Tickets: " + colors.cyan.underline(totalTickets.toLocaleString('en-US')));
        }

        let logMsg = `\n\n[${new Date().toLocaleString()}] [READY] Bot is now ready!`;
        fs.appendFile("./logs.txt", logMsg, (e) => {
            if (e) console.log(e);
        });

        if (updatedGuildData.timesBotStarted === 1) {
            cfonts.say('Thank you!', {
                font: 'simple',
                align: 'left',
                colors: ['#33aaee', '#4455dd'],
                background: 'transparent',
                letterSpacing: 1,
                lineHeight: 1,
                space: true,
                maxLength: '0',
                gradient: ['#33aaee', '#4455dd']
            });

            console.log(`Since this is your first time starting the bot, here is some important information:`);
            console.log(``);
            console.log(`If you need any help, create a ticket in our Discord server.`);
            console.log(`You can also look at our documentation for help: ${colors.cyan(`https://docs.drakodevelopment.net`)}`);
            console.log(``);
            console.log(`${colors.bold.red(`Leaking or redistributing any of our products is not allowed. If you are found doing it, your license will be permanently disabled!`)}`);
            console.log(`By using this bot, you agree to all terms located here: ${colors.cyan(`https://docs.drakodevelopment.net/terms-and-conditions/`)}`);
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}