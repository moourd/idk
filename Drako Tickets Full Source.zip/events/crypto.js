const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const axios = require('axios');
const fs = require('fs');
const yaml = require('js-yaml');
const Transaction = require('../models/Transaction');
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'));

const blockCypherAPI = config.API.BlockCypher.Enabled ? axios.create({
    baseURL: 'https://api.blockcypher.com/v1',
    headers: { 'Content-Type': 'application/json' }
}) : null;

async function handleCryptoButton(interaction, interactionKey) {
    if (interaction.customId === 'crypto_submit') {
        const modal = new ModalBuilder()
            .setCustomId('submitTransactionModal')
            .setTitle('Submit Transaction ID')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('transactionId')
                        .setLabel('Transaction ID')
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('Enter the transaction ID')
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);
    } else if (interaction.customId === 'crypto_paste') {
        await interaction.reply({ content: `Wallet Address: ${interaction.message.embeds[0].description.match(/`([^`]+)`/)[1]}`, ephemeral: true });
    } else if (interaction.customId === 'crypto_qr') {
        const transaction = await Transaction.findOne({ messageId: interaction.message.id });
        if (transaction) {
            await interaction.reply({ content: `QR Code: ${transaction.qrCodeURL}`, ephemeral: true });
        } else {
            await interaction.reply({ content: 'QR code not found.', ephemeral: true });
        }
    }
}

async function verifyTransactionId(transactionId, transaction) {
    try {
        let response;

        if (config.API.BlockCypher.Enabled) {
            response = await verifyWithBlockCypher(transactionId, transaction.coin);
        }

        if (!response || !response.data) {
            return { isValid: false, message: `Transaction ${transactionId} not found.` };
        }

        const responseData = response.data;

        if (!responseData.received || !responseData.total || !responseData.outputs) {
            return { isValid: false, message: 'Invalid response structure from BlockCypher.' };
        }

        const transactionTimestamp = new Date(responseData.received);
        const commandTimestamp = new Date(transaction.commandTimestamp);

        if (transactionTimestamp < commandTimestamp) {
            return { isValid: false, message: 'Transaction timestamp is before the command was run.' };
        }

        let validOutput = null;
        for (const output of responseData.outputs) {
            if (output.addresses.includes(transaction.address)) {
                const actualAmount = parseFloat(output.value / 1e8);
                const lowerBound = transaction.requestedAmount * 0.95;
                const upperBound = transaction.requestedAmount * 1.05;

                if (actualAmount >= lowerBound && actualAmount <= upperBound) {
                    validOutput = output;
                    break;
                } else {
                    console.log(`Output amount ${actualAmount} is not within 5% of the requested amount ${transaction.requestedAmount}.`);
                }
            }
        }

        if (!validOutput) {
            console.log('Transaction was not sent to the correct address with the correct amount.');
            return { isValid: false, message: 'Transaction was not sent to the correct address with the correct amount.' };
        }

        transaction.confirmations = responseData.confirmations || 0;

        if (transaction.confirmations < 3) {
            transaction.status = 'Pending Confirmation';
            await transaction.save();
            return { isValid: true, message: 'Transaction is pending confirmation.' };
        }

        await Transaction.updateOne(
            { messageId: transaction.messageId },
            {
                $set: {
                    validationSite: 'BlockCypher',
                    status: 'Completed',
                    transactionId: transactionId,
                    confirmations: transaction.confirmations,
                }
            }
        );

        return { isValid: true, message: 'Transaction verified successfully.' };
    } catch (error) {
        console.error('Error verifying transaction ID:', error);
        return { isValid: false, message: 'Internal error verifying transaction ID.' };
    }
}

async function verifyWithBlockCypher(transactionId, coin) {
    try {
        const coinMapping = {
            'BTC': 'btc',
            'LTC': 'ltc',
            'ETH': 'eth',
            'DOGE': 'doge',
        };

        const coinType = coinMapping[coin.toUpperCase()];
        if (!coinType) {
            throw new Error(`Unsupported coin type: ${coin}`);
        }

        const response = await blockCypherAPI.get(`/${coinType}/main/txs/${transactionId}?token=${config.API.BlockCypher.API}`);
        if (response && response.data && response.data.hash === transactionId) {
            return { isValid: true, data: response.data };
        }
    } catch (error) {
        console.error(`Error verifying transaction ID with BlockCypher:`, error.response ? error.response.data : error.message);
    }
    return { isValid: false };
}

async function trackTransaction(transaction) {
    const interval = setInterval(async () => {
        try {
            const response = await verifyWithBlockCypher(transaction.transactionId, transaction.coin);
            if (response.isValid) {
                transaction.confirmations = response.data.confirmations || 0;

                if (transaction.confirmations >= 3) {
                    transaction.status = 'Completed';
                    await transaction.save();

                    const message = await client.channels.cache.get(transaction.channelId).messages.fetch(transaction.messageId);
                    if (message) {
                        const embed = EmbedBuilder.from(message.embeds[0])
                            .setDescription(message.embeds[0].description.replace(lang.Crypto.Messages.PendingVerification?.Lang || 'Pending Verification', lang.Crypto.Messages.Completed.Lang))
                            .setColor(lang.Crypto.Messages.Completed.Color);

                        await message.edit({ embeds: [embed] });
                    }

                    clearInterval(interval);
                    return;
                }
            }
        } catch (error) {
            console.error('Error tracking transaction:', error);
        }
    }, 60000);
}

module.exports = async (client) => {
    client.on('interactionCreate', async (interaction) => {
        if (interaction.isButton() && interaction.customId.startsWith('crypto_')) {
            await handleCryptoButton(interaction, `${interaction.user.id}-${interaction.customId}`);
        }

        if (interaction.isModalSubmit() && interaction.customId === 'submitTransactionModal') {
            const transactionId = interaction.fields.getTextInputValue('transactionId');

            if (!interaction.replied && !interaction.deferred) {
                await interaction.deferReply({ ephemeral: true });
            }

            const transaction = await Transaction.findOne({ messageId: interaction.message.id });
            if (!transaction) {
                await interaction.followUp({ content: 'Transaction not found.', ephemeral: true });
                return;
            }

            const validationResult = await verifyTransactionId(transactionId, transaction);
            if (!validationResult.isValid) {
                return interaction.followUp({ content: `Invalid transaction ID: ${validationResult.message}`, ephemeral: true });
            }

            const updatedDescription = interaction.message.embeds[0].description
                .replace(lang.Crypto.Messages.Pending.Lang, lang.Crypto.Messages.Completed.Lang)
                .replace(lang.Crypto.Messages.Transaction, transactionId);

            const embed = EmbedBuilder.from(interaction.message.embeds[0])
                .setDescription(updatedDescription)
                .setColor(lang.Crypto.Messages.Completed.Color);

            const buttons = [
                new ButtonBuilder()
                    .setLabel(lang.Crypto.Embed.Buttons[0].Name)
                    .setStyle(ButtonStyle.Success)
                    .setCustomId('crypto_submit')
                    .setDisabled(true),
                new ButtonBuilder()
                    .setLabel(lang.Crypto.Embed.Buttons[1].Name)
                    .setStyle(ButtonStyle.Primary)
                    .setCustomId('crypto_paste'),
                new ButtonBuilder()
                    .setLabel(lang.Crypto.Embed.Buttons[2].Name)
                    .setStyle(ButtonStyle.Primary)
                    .setCustomId('crypto_qr'),
                new ButtonBuilder()
                    .setLabel(lang.Crypto.Embed.Buttons[3].Name)
                    .setStyle(ButtonStyle.Link)
                    .setURL(lang.Crypto.Embed.Buttons[3].Link),
                new ButtonBuilder()
                    .setLabel('View Transaction')
                    .setStyle(ButtonStyle.Link)
                    .setURL(`https://live.blockcypher.com/ltc/tx/${transactionId}/`)
            ];

            const row = new ActionRowBuilder().addComponents(buttons);

            const channel = await client.channels.fetch(transaction.channelId);
            const originalMessage = await channel.messages.fetch(transaction.messageId);

            await originalMessage.edit({ embeds: [embed], components: [row] });
            await interaction.followUp({ content: 'Transaction ID submitted successfully.', ephemeral: true });
        }
    });

    const transactions = await Transaction.find({ status: 'Pending Verification' });
    transactions.forEach(trackTransaction);

    setInterval(async () => {
        const transactions = await Transaction.find({ status: 'Pending Verification' });
        transactions.forEach(trackTransaction);
    }, 120000);
};