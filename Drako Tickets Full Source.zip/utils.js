﻿const { Collection, ActivityType, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ContextMenuCommandBuilder, REST, Routes } = require('discord.js');
const fs = require('fs');
const yaml = require('js-yaml');
const path = require('path');
const colors = require('colors');
const axios = require('axios');
const glob = require('glob');
const client = require('./index.js');
const packageJson = require('./package.json');
const { startAlertScheduler } = require('./events/Tickets/checkAlerts');
const Ticket = require('./models/tickets');
const Transaction = require('./models/Transaction');
const Invoice = require('./models/invoice');
const GuildData = require('./models/guildDataSchema');

const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'));
const commandConfig = yaml.load(fs.readFileSync('./commands.yml', 'utf8'));

const isSandbox = config.PayPalSettings.Sandbox || false;
const paypalApiBaseUrl = isSandbox ? 'https://api.sandbox.paypal.com' : 'https://api.paypal.com';

client.commands = new Collection();
client.slashCommands = new Collection();
client.snipes = new Collection();

client.on('messageCreate', handleMessageCreate);
client.on('interactionCreate', async (interaction) => handleInteractionCreate(interaction));
client.on('ready', handleReady);
client.on('error', handleError);
client.on('warn', handleWarn);

const slashCommands = [];
const interactionDebounce = new Map();

const cryptoHandler = require('./events/crypto');
cryptoHandler(client);

const blockCypherAPI = config.API.BlockCypher.Enabled ? axios.create({
    baseURL: 'https://api.blockcypher.com/v1',
    headers: { 'Content-Type': 'application/json' }
}) : null;

async function handleMessageCreate(message) {
    if (message.author.bot) return;
    if (!message.guild) return;

    handleTicketAlertReset(message);

    GuildData.findOneAndUpdate(
        { guildID: message.guild.id },
        { $inc: { totalMessages: 1 } },
        { new: true, upsert: true }
    ).then(updatedDoc => {
    }).catch(err => {
        console.error(`Failed to update totalMessages for guild ${message.guild.id}:`, err);
    });
}

async function handleTicketAlertReset(message) {
    const ticket = await Ticket.findOne({ channelId: message.channel.id, status: 'open' });

    if (ticket && message.author.id === ticket.userId) {
        ticket.alertTime = null;
        if (ticket.alertMessageId) {
            const alertMessage = await message.channel.messages.fetch(ticket.alertMessageId).catch(() => null);
            if (alertMessage) await alertMessage.delete();
            ticket.alertMessageId = null;
        }
        await ticket.save();
    }
}

async function handleInteractionCreate(interaction) {
    if (interaction.isCommand()) {
        const command = client.slashCommands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, client);
        } catch (error) {
            console.error(error);
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
            } else if (interaction.deferred) {
                await interaction.followUp({ content: 'There was an error while executing this command!', ephemeral: true });
            }
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith('paypal_updateStatus_')) {
        await handlePayPalButton(interaction, interaction.customId);
    }
}

async function handlePayPalButton(interaction, customId) {
    const invoiceId = customId.split('_').pop();
    console.log(`PayPal button clicked: ${customId}`);

    try {
        const invoice = await Invoice.findOne({ invoiceId });

        if (!invoice) {
            await interaction.reply({ content: 'Invoice not found.', ephemeral: true });
            return;
        }

        const authResponse = await axios({
            method: 'post',
            url: `${paypalApiBaseUrl}/v1/oauth2/token`,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Basic ${Buffer.from(`${config.PayPalSettings.ClientID}:${config.PayPalSettings.Secret}`).toString('base64')}`
            },
            data: 'grant_type=client_credentials'
        });

        const accessToken = authResponse.data.access_token;

        const invoiceStatusResponse = await axios({
            method: 'get',
            url: `${paypalApiBaseUrl}/v2/invoicing/invoices/${invoiceId}`,
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        });

        const invoiceStatus = invoiceStatusResponse.data.status.toLowerCase();
        const statusMapping = {
            paid: 'Paid',
            unpaid: 'Unpaid',
            cancelled: 'Cancelled',
            sent: 'Unpaid',
            draft: 'Unpaid'
        };

        const mappedStatus = statusMapping[invoiceStatus];
        if (!mappedStatus) {
            await interaction.reply({ content: 'Unknown invoice status.', ephemeral: true });
            return;
        }

        const replacements = {
            seller: config.PayPalSettings.Email,
            buyer: `<@${invoice.userId}>`,
            invoiceID: invoiceId,
            currency: config.PayPalSettings.Currency,
            price: `${config.PayPalSettings.Symbol}${invoice.price}`,
            service: invoice.product,
            status: lang.Paypal.Messages[mappedStatus]?.Message || 'Unknown Status',
        };

        const embed = new EmbedBuilder()
            .setColor(lang.Paypal.Messages[mappedStatus]?.Color || lang.Paypal.Messages.Unpaid.Color)
            .setTitle(replacePlaceholders(lang.Paypal.Embed.Title, replacements))
            .setDescription(lang.Paypal.Embed.Description.map(line => replacePlaceholders(line, replacements)).join('\n'));

        if (lang.Paypal.Embed.Fields) {
            lang.Paypal.Embed.Fields.forEach(field => {
                if (field.name && field.value) {
                    embed.addFields({
                        name: replacePlaceholders(field.name, replacements),
                        value: replacePlaceholders(field.value, replacements),
                        inline: field.inline
                    });
                }
            });
        }

        if (lang.Paypal.Embed.Footer.Text) {
            embed.setFooter({
                text: replacePlaceholders(lang.Paypal.Embed.Footer.Text, replacements),
                iconURL: lang.Paypal.Embed.Footer.Icon || undefined
            });
        }

        if (lang.Paypal.Embed.Author.Text) {
            embed.setAuthor({
                name: replacePlaceholders(lang.Paypal.Embed.Author.Text, replacements),
                iconURL: lang.Paypal.Embed.Author.Icon || undefined
            });
        }

        if (lang.Paypal.Embed.Image) {
            embed.setImage(lang.Paypal.Embed.Image);
        }

        if (lang.Paypal.Embed.Thumbnail) {
            embed.setThumbnail(lang.Paypal.Embed.Thumbnail);
        }

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel(replacePlaceholders(lang.Paypal.Embed.Buttons.Pay.Name, replacements))
                    .setStyle(ButtonStyle.Link)
                    .setEmoji(lang.Paypal.Embed.Buttons.Pay.Emoji)
                    .setURL(`https://www.${isSandbox ? 'sandbox.' : ''}paypal.com/invoice/payerView/details/${invoiceId}`),
                new ButtonBuilder()
                    .setCustomId(`paypal_updateStatus_${invoiceId}`)
                    .setLabel(replacePlaceholders(lang.Paypal.Embed.Buttons.Status.Name, replacements))
                    .setStyle(ButtonStyle.Success)
                    .setEmoji(lang.Paypal.Embed.Buttons.Status.Emoji)
                    .setDisabled(mappedStatus === 'Paid')
            );

        await interaction.update({ embeds: [embed], components: [buttons] });

        invoice.status = mappedStatus;
        await invoice.save();

        if (mappedStatus === 'Paid') {
            const guild = await client.guilds.fetch(invoice.guildId);
            const member = await guild.members.fetch(invoice.userId);
            if (config.PayPalSettings.CustomerRole.length > 0 && /^\d{18}$/.test(config.PayPalSettings.CustomerRole)) {
                try {
                    await member.roles.add(config.PayPalSettings.CustomerRole);
                } catch (err) {
                    console.error(`Failed to add role ${config.PayPalSettings.CustomerRole} to user ${invoice.userId}:`, err);
                }
            }
        }
    } catch (error) {
        console.error('Error handling PayPal button:', error.response ? error.response.data : error.message);
        await interaction.reply({ content: 'There was an error processing the PayPal button.', ephemeral: true });
    }
}

async function handleReady() {
    const nodeVersion = process.version;
    const appVersion = packageJson.version;
    const date = new Date();
    const formattedDate = `${date.getHours()}:${date.getMinutes()} (${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()})`;
    fs.appendFile('logs.txt', `${formattedDate} - Bot started up - Node.js ${nodeVersion} - App Version ${appVersion}\n`, (err) => {
        if (err) {
            console.error('Failed to write to log file:', err);
        }
    });

    if (config.Alert && config.Alert.Enabled) {
        startAlertScheduler(client);
    }

    setInterval(async () => {
        await scheduleInvoiceChecks();
    }, 30000);

    setInterval(async () => {
        await checkAndUpdateTicketStatus(client);
    }, 300000);

    const rest = new REST({ version: '10' }).setToken(config.BotToken);
    try {
        await rest.put(
            Routes.applicationGuildCommands(client.user.id, config.GuildID),
            { body: slashCommands }
        );
    } catch (error) {
        console.error(`${colors.red('[ERROR]')} Failed to register slash commands.`);
        console.error(error);
        fs.appendFileSync('logs.txt', `${new Date().toISOString()} - ERROR: ${JSON.stringify(error, null, 2)}\n`);

        if (error.message.includes("application.commands scope")) {
            console.error(`${colors.red('[ERROR]')} Application.commands scope wasn't selected when inviting the bot.`);
            console.error(`${colors.red('[ERROR]')} Invite the bot using the following URL:`);
            console.error(`${colors.red(`[ERROR] https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)}`);
        }
    }
}

function handleError(error) {
    const logMessage = `${new Date().toISOString()} - ERROR: ${error}\n`;
    console.error(logMessage);
    fs.appendFile('logs.txt', logMessage, (err) => {
        if (err) {
            console.error('Failed to write to log file:', err);
        }
    });
}

function handleWarn(info) {
    const logMessage = `${new Date().toISOString()} - WARN: ${info}\n`;
    console.warn(logMessage);
    fs.appendFile('logs.txt', logMessage, (err) => {
        if (err) {
            console.error('Failed to write to log file:', err);
        }
    });
}

function loadSlashCommands(directory) {
    const items = fs.readdirSync(directory, { withFileTypes: true });

    for (const item of items) {
        const itemPath = path.join(directory, item.name);

        if (item.isDirectory()) {
            loadSlashCommands(itemPath);
        } else if (item.isFile() && item.name.endsWith('.js')) {
            try {
                const command = require(itemPath);

                if (command.data instanceof SlashCommandBuilder) {
                    if (commandConfig[command.data.name]) {
                        console.log(`${colors.bgBrightCyan.brightWhite(' SLASH COMMANDS ')} ${command.data.name} loaded!`);
                        slashCommands.push(command.data.toJSON());
                        client.slashCommands.set(command.data.name, command);
                    } else {
                        console.log(`${colors.bgBrightCyan.brightWhite(' SLASH COMMANDS ')} ${command.data.name} is disabled! (commands.yml)`);
                    }
                } else if (command.data instanceof ContextMenuCommandBuilder) {
                    if (commandConfig[command.data.name]) {
                        console.log(`${colors.bgBrightCyan.brightWhite(' SLASH COMMANDS ')} ${command.data.name} loaded!`);
                        slashCommands.push(command.data.toJSON());
                        client.slashCommands.set(command.data.name, command);
                    } else {
                        console.log(`${colors.bgBrightCyan.brightWhite(' SLASH COMMANDS ')} ${command.data.name} is disabled! (commands.yml)`);
                    }
                } else if (Array.isArray(command.data) && command.data.every(cmd => cmd instanceof ContextMenuCommandBuilder)) {
                    command.data.forEach(cmd => {
                        if (commandConfig[cmd.name]) {
                            console.log(`${colors.bgBrightCyan.brightWhite(' SLASH COMMANDS ')} ${cmd.name} loaded!`);
                            slashCommands.push(cmd.toJSON());
                            client.slashCommands.set(cmd.name, command);
                        } else {
                            console.log(`${colors.bgBrightCyan.brightWhite(' SLASH COMMANDS ')} ${cmd.name} is disabled! (commands.yml)`);
                        }
                    });
                }
            } catch (error) {
                console.error(`${colors.bgRed.black(' ERROR ')} Error loading ${item.name}:`, error);
            }
        }
    }
}

loadSlashCommands(path.join(__dirname, 'commands'));

glob('./addons/**/*.js', function (err, files) {
    if (err) return console.error(err);

    const loadedAddons = [];

    files.forEach(file => {
        if (file.endsWith('.js')) {
            const folderName = file.match(/\/addons\/([^/]+)/)[1];

            if (!loadedAddons.includes(folderName)) {
                loadedAddons.push(folderName);
                console.log(`${colors.bgBrightCyan.brightWhite(' ADDON ')} ${folderName} loaded!`);
            }

            try {
                if (file.search("cmd_") >= 0) {
                    let comm = require(file);
                    if (comm && comm.data && comm.data.toJSON && typeof comm.data.toJSON === 'function') {
                        slashCommands.push(comm.data.toJSON());
                        client.slashCommands.set(comm.data.name, comm);
                    }
                } else {
                    let event = require(file);
                    if (event && event.run && typeof event.run === 'function') {
                        event.run(client);
                    }
                }
            } catch (addonError) {
                console.error(`${colors.bgRed.brightWhite(`[ERROR] ${folderName}: ${addonError.message}`)}`);
                console.error(addonError.stack);
            }
        }
    });
});

async function checkAndUpdateTicketStatus(client) {
    try {
        const tickets = await Ticket.find({
            status: { $in: ['open', 'closed'] }
        });

        for (const ticket of tickets) {
            const channel = await client.channels.cache.get(ticket.channelId) || await client.channels.fetch(ticket.channelId).catch(() => null);

            if (!channel) {
                ticket.status = 'deleted';
                ticket.deletedAt = new Date();
                await ticket.save();
            }
        }
    } catch (error) {
        console.error('Error checking and updating ticket status:', error);
    }
}

async function scheduleInvoiceChecks() {
    let invoicesToCheck = await Invoice.find({ status: { $ne: 'PAID' } });

    invoicesToCheck = invoicesToCheck.filter(invoice => invoice.status.toLowerCase() !== 'paid');

    invoicesToCheck.forEach(invoice => {
        const checkInterval = setInterval(async () => {
            try {
                const status = await checkInvoiceStatus(invoice);

                const normalizedStatus = status.toLowerCase();
                const statusMapping = {
                    paid: 'Paid',
                    unpaid: 'Unpaid',
                    cancelled: 'Cancelled',
                    sent: 'Unpaid',
                    draft: 'Unpaid'
                };

                const mappedStatus = statusMapping[normalizedStatus];
                if (!mappedStatus) {
                    return;
                }

                if (mappedStatus !== invoice.status) {

                    const channel = await client.channels.fetch(invoice.channelId).catch(err => {
                        console.error(`Failed to fetch channel ${invoice.channelId}:`, err);
                    });

                    if (channel) {
                        const message = await channel.messages.fetch(invoice.messageId).catch(async (err) => {
                            if (err.code === 10008) {
                                await Invoice.deleteOne({ _id: invoice._id });
                                clearInterval(checkInterval);
                                return null;
                            } else {
                                console.error(`Failed to fetch message ${invoice.messageId}:`, err);
                            }
                        });

                        if (message) {
                            const replacements = {
                                seller: config.PayPalSettings.Email,
                                buyer: `<@${invoice.userId}>`,
                                invoiceID: invoice.invoiceId,
                                currency: config.PayPalSettings.Currency,
                                price: `${config.PayPalSettings.Symbol}${invoice.price}`,
                                service: invoice.product,
                                status: lang.Paypal.Messages[mappedStatus] ? lang.Paypal.Messages[mappedStatus].Message : 'Unknown Status',
                            };

                            replacements.status = lang.Paypal.Messages[mappedStatus]?.Message || 'Unknown Status';

                            const embed = new EmbedBuilder()
                                .setColor(lang.Paypal.Messages[mappedStatus]?.Color || lang.Paypal.Messages.Unpaid.Color);

                            const title = replacePlaceholders(lang.Paypal.Embed.Title, replacements);
                            if (title) {
                                embed.setTitle(title);
                            }

                            if (lang.Paypal.Embed.Description) {
                                const description = lang.Paypal.Embed.Description
                                    .map(line => replacePlaceholders(line, replacements))
                                    .filter(line => line)
                                    .join('\n');
                                if (description) {
                                    embed.setDescription(description);
                                }
                            }

                            if (lang.Paypal.Embed.Fields) {
                                lang.Paypal.Embed.Fields.forEach(field => {
                                    const fieldName = replacePlaceholders(field.name, replacements);
                                    const fieldValue = replacePlaceholders(field.value, replacements);
                                    if (fieldName && fieldValue) {
                                        embed.addFields({
                                            name: fieldName,
                                            value: fieldValue,
                                            inline: field.inline
                                        });
                                    }
                                });
                            }

                            const footerText = replacePlaceholders(lang.Paypal.Embed.Footer.Text, replacements);
                            if (footerText) {
                                embed.setFooter({
                                    text: footerText,
                                    iconURL: lang.Paypal.Embed.Footer.Icon || undefined
                                });
                            }

                            const authorText = replacePlaceholders(lang.Paypal.Embed.Author.Text, replacements);
                            if (authorText) {
                                embed.setAuthor({
                                    name: authorText,
                                    iconURL: lang.Paypal.Embed.Author.Icon || undefined
                                });
                            }

                            if (lang.Paypal.Embed.Image) {
                                embed.setImage(lang.Paypal.Embed.Image);
                            }

                            if (lang.Paypal.Embed.Thumbnail) {
                                embed.setThumbnail(lang.Paypal.Embed.Thumbnail);
                            }

                            const buttons = new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setLabel(lang.Paypal.Embed.Buttons.Pay.Name)
                                        .setStyle(ButtonStyle.Link)
                                        .setEmoji(lang.Paypal.Embed.Buttons.Pay.Emoji)
                                        .setURL(`https://www.${isSandbox ? 'sandbox.' : ''}paypal.com/invoice/payerView/details/${invoice.invoiceId}`),
                                    new ButtonBuilder()
                                        .setCustomId(`paypal_updateStatus_${invoice.invoiceId}`)
                                        .setLabel(lang.Paypal.Embed.Buttons.Status.Name)
                                        .setStyle(ButtonStyle.Success)
                                        .setEmoji(lang.Paypal.Embed.Buttons.Status.Emoji)
                                        .setDisabled(mappedStatus === 'Paid')
                                );

                            await message.edit({ embeds: [embed], components: [buttons] });

                            invoice.status = mappedStatus;
                            await invoice.save();

                            if (mappedStatus === 'Paid') {
                                const guild = await client.guilds.fetch(invoice.guildId);
                                const member = await guild.members.fetch(invoice.userId);
                                if (config.PayPalSettings.CustomerRole.length > 0 && /^\d{18}$/.test(config.PayPalSettings.CustomerRole)) {
                                    try {
                                        await member.roles.add(config.PayPalSettings.CustomerRole);
                                    } catch (err) {
                                        console.error(`Failed to add role ${config.PayPalSettings.CustomerRole} to user ${invoice.userId}:`, err);
                                    }
                                }
                            }
                        }
                    } else {
                        console.error(`Channel not found: ${invoice.channelId}`);
                    }
                }
            } catch (error) {
                console.error(`Error during invoice status check for ${invoice.invoiceId}:`, error);
            }
        }, 30000);
    });
}

async function checkInvoiceStatus(invoice) {
    try {
        const authResponse = await axios({
            method: 'post',
            url: `${paypalApiBaseUrl}/v1/oauth2/token`,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Basic ${Buffer.from(`${config.PayPalSettings.ClientID}:${config.PayPalSettings.Secret}`).toString('base64')}`
            },
            data: 'grant_type=client_credentials'
        });

        const accessToken = authResponse.data.access_token;

        const invoiceStatus = await axios({
            method: 'get',
            url: `${paypalApiBaseUrl}/v2/invoicing/invoices/${invoice.invoiceId}`,
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        });

        return invoiceStatus.data.status;
    } catch (error) {
        console.error(`Error checking invoice status for ${invoice.invoiceId}:`, error);
        throw error;
    }
}

function replacePlaceholders(text, replacements) {
    return text.replace(/{(.*?)}/g, (_, key) => replacements[key] || '');
}

fs.readdir('./events/', async (err, files) => {
    if (err) return console.error;

    files.forEach(file => {
        if (!file.endsWith('.js')) return;

        const evt = require(`./events/${file}`);
        let evtName = file.split('.')[0];

        if (typeof evt !== 'function') {
            console.log(`${colors.bgBrightCyan.brightWhite(' EVENT ')} ${file} does not export a function. Skipping...`);
            return;
        }

        client.on(evtName, evt.bind(null, client));
        console.log(`${colors.bgBrightCyan.brightWhite(' EVENT ')} ${file} loaded!`);

    });
});

client.login(config.BotToken).catch(error => {
    if (error.message.includes("Used disallowed intents")) {
        console.log('\x1b[31m%s\x1b[0m', `Used disallowed intents (READ HOW TO FIX): \n\nYou did not enable Privileged Gateway Intents in the Discord Developer Portal!\nTo fix this, you have to enable all the privileged gateway intents in your discord developer portal, you can do this by opening the discord developer portal, go to your application, click on bot on the left side, scroll down and enable Presence Intent, Server Members Intent, and Message Content Intent`);
        process.exit();
    } else if (error.message.includes("An invalid token was provided")) {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] The bot token specified in the config is incorrect!`);
        process.exit();
    } else {
        console.log('\x1b[31m%s\x1b[0m', `[ERROR] An error occurred while attempting to login to the bot`);
        console.log(error);
        process.exit();
    }
});