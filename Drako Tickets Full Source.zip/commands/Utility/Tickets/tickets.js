﻿const {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    StringSelectMenuBuilder,
    PermissionFlagsBits,
    ButtonStyle,
    ChannelType,
    AttachmentBuilder
} = require('discord.js');
const fs = require('fs');
const yaml = require('js-yaml');
const path = require('path');
const moment = require('moment-timezone');
const Ticket = require('../../../models/tickets');
const Blacklist = require('../../../models/blacklist');
const { ChartJSNodeCanvas } = require('chartjs-node-canvas');
const { handleTicketClose } = require('../../../events/interactionCreate');

const configPath = path.join(__dirname, '../../../config.yml');
const langPath = path.join(__dirname, '../../../lang.yml');

const config = yaml.load(fs.readFileSync(configPath, 'utf8'));
const lang = yaml.load(fs.readFileSync(langPath, 'utf8'));

function parseDuration(duration) {
    const timeUnits = {
        s: 1000,
        m: 1000 * 60,
        h: 1000 * 60 * 60,
        d: 1000 * 60 * 60 * 24,
        w: 1000 * 60 * 60 * 24 * 7
    };

    const matches = duration.match(/(\d+\s*[smhdw])/g);
    if (!matches) {
        throw new Error(`Invalid duration format: ${duration}`);
    }

    return matches.reduce((total, match) => {
        const value = parseInt(match.match(/\d+/)[0]);
        const unit = match.match(/[smhdw]/)[0];
        return total + value * timeUnits[unit];
    }, 0);
}

function isValidHttpUrl(string) {
    try {
        const url = new URL(string);
        return url.protocol === "http:" || url.protocol === "https:";
    } catch (_) {
        return false;
    }
}

function hasSupportRole(member, roles) {
    return member.roles.cache.some(role => roles.includes(role.id));
}

function formatDuration(ms) {
    const duration = moment.duration(ms);
    const days = duration.days();
    const hours = duration.hours();
    const minutes = duration.minutes();
    const seconds = duration.seconds();

    if (days > 0) {
        return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else if (minutes > 0) {
        return `${minutes}m ${seconds}s`;
    } else {
        return `${seconds}s`;
    }
}

async function getUserPriority(member) {
    const priorityConfig = config.Priority;
    if (!priorityConfig.Enabled) {
        return priorityConfig.DefaultPriority;
    }

    for (const level of Object.keys(priorityConfig.Levels)) {
        const levelConfig = priorityConfig.Levels[level];
        for (const roleId of levelConfig.Roles) {
            if (member.roles.cache.has(roleId)) {
                return level;
            }
        }
    }

    return priorityConfig.DefaultPriority;
}

const replacePlaceholders = (text, placeholders) => {
    if (!text) return '';
    Object.keys(placeholders).forEach(placeholder => {
        text = text.replace(`{${placeholder}}`, placeholders[placeholder]);
    });
    return text;
};

async function updateChannelPermissions(channel, newTicketType, userId) {
    try {
        const permissionOverwrites = [
            {
                id: channel.guild.roles.everyone.id,
                deny: ['SendMessages', 'ViewChannel']
            },
            {
                id: userId,
                allow: ['SendMessages', 'ViewChannel', 'AttachFiles', 'EmbedLinks', 'ReadMessageHistory']
            }
        ];

        newTicketType.SupportRole.forEach(roleId => {
            const role = channel.guild.roles.cache.get(roleId);
            if (role) {
                permissionOverwrites.push({
                    id: role.id,
                    allow: ['SendMessages', 'ViewChannel', 'AttachFiles', 'EmbedLinks', 'ReadMessageHistory']
                });
            }
        });

        await channel.permissionOverwrites.set(permissionOverwrites);
    } catch (error) {
        console.error('Error updating channel permissions:', error);
        throw new Error('Failed to update channel permissions');
    }
}

async function moveChannel(channel, newCategoryId) {
    try {
        await channel.setParent(newCategoryId, { lockPermissions: false });
    } catch (error) {
        console.error('Error moving channel:', error);
        throw new Error('Failed to move channel');
    }
}

async function renameChannel(channel, newName) {
    try {
        await channel.setName(newName);
    } catch (error) {
        console.error('Error renaming channel:', error);
        throw new Error('Failed to rename channel');
    }
}

async function generateTicketsGraph(tickets) {
    const dates = Array.from({ length: 7 }).map((_, i) => moment().subtract(i, 'days').format('Do MMM')).reverse();
    const counts = dates.map(date => tickets.filter(ticket => moment(ticket.createdAt).format('Do MMM') === date).length);

    const chartJSNodeCanvas = new ChartJSNodeCanvas({ width: 800, height: 400 });
    const configuration = {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Ticket Stats',
                data: counts,
                fill: false,
                borderColor: 'rgb(255, 0, 0)',
                pointBackgroundColor: 'white',
                pointBorderColor: 'white',
                pointRadius: 5,
                pointHoverRadius: 7,
                tension: 0.1
            }]
        },
        options: {
            scales: {
                x: {
                    title: { display: true, text: 'Date' },
                    ticks: {
                        color: '#FFFFFF',
                        font: {
                            weight: 'bold',
                            size: 22
                        }
                    }
                },
                y: {
                    title: { display: false },
                    ticks: {
                        color: '#FFFFFF',
                        font: {
                            weight: 'bold',
                            size: 22
                        }
                    }
                }
            }
        }
    };

    const imageBuffer = await chartJSNodeCanvas.renderToBuffer(configuration);
    return imageBuffer.toString('base64');
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tickets')
        .setDescription('Various ticket commands for managing tickets')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add a user to the ticket')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('The user to add to the ticket')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('alert')
                .setDescription('Send an alert about pending ticket closure.')
        )
        .addSubcommandGroup(group =>
            group
                .setName('blacklist')
                .setDescription('Manage the blacklist')
                .addSubcommand(subcommand =>
                    subcommand
                        .setName('add')
                        .setDescription('Blacklist a user from opening tickets')
                        .addUserOption(option =>
                            option.setName('user')
                                .setDescription('The user to blacklist')
                                .setRequired(true)
                        )
                        .addStringOption(option =>
                            option.setName('reason')
                                .setDescription('Reason for blacklisting')
                                .setRequired(false)
                        )
                )
                .addSubcommand(subcommand =>
                    subcommand
                        .setName('view')
                        .setDescription('View the blacklist reason for a user')
                        .addUserOption(option =>
                            option.setName('user')
                                .setDescription('The user to check')
                                .setRequired(true)
                        )
                )
                .addSubcommand(subcommand =>
                    subcommand
                        .setName('remove')
                        .setDescription('Remove a user from the blacklist')
                        .addUserOption(option =>
                            option.setName('user')
                                .setDescription('The user to remove from the blacklist')
                                .setRequired(true)
                        )
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('close')
                .setDescription('Close the current ticket')
                .addStringOption(option =>
                    option.setName('reason')
                        .setDescription('Reason for closing the ticket')
                        .setRequired(false)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('Send the ticket panel')
                .addStringOption(option => {
                    option.setName('panel')
                        .setDescription('The panel to display')
                        .setRequired(true);

                    Object.keys(config.TicketPanelSettings).forEach(panel => {
                        option.addChoices({ name: panel, value: panel });
                    });

                    return option;
                })
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove a user from the ticket')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('The user to remove from the ticket')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('rename')
                .setDescription('Rename the ticket channel')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('The new name for the ticket channel')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('Show general ticket stats')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('voice')
                .setDescription('Create a temporary voice channel for the ticket')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('transfer')
                .setDescription('Transfer a ticket to a new type')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('The new ticket type')
                        .setRequired(true)
                        .addChoices(
                            Object.keys(config.TicketTypes).map(key => ({
                                name: config.TicketTypes[key].Name,
                                value: key
                            }))
                        )
                )
        ),
    async execute(interaction) {
        try {
            const subcommand = interaction.options.getSubcommand();
            const group = interaction.options.getSubcommandGroup(false);

            if (subcommand === 'add' && !group) {
                try {
                    const userToAdd = interaction.options.getUser('user');
                    const ticket = await Ticket.findOne({ channelId: interaction.channel.id });

                    if (!ticket) {
                        return interaction.reply({ content: 'This command can only be used within a ticket channel.', ephemeral: true });
                    }

                    const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole;
                    const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                    if (!hasSupportRole) {
                        return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                    }

                    const channel = interaction.channel;

                    if (channel.type === ChannelType.GuildText) {
                        const permissions = channel.permissionsFor(userToAdd);
                        if (permissions && permissions.has(PermissionFlagsBits.ViewChannel)) {
                            return interaction.reply({ content: 'User is already added to this ticket.', ephemeral: true });
                        }

                        await channel.permissionOverwrites.create(userToAdd, {
                            ViewChannel: true,
                            SendMessages: true,
                            ReadMessageHistory: true,
                            AttachFiles: true,
                            EmbedLinks: true
                        });
                    } else if (channel.type === ChannelType.PrivateThread || channel.type === ChannelType.PublicThread) {
                        const members = await channel.members.fetch();
                        if (members.has(userToAdd.id)) {
                            return interaction.reply({ content: 'User is already added to this ticket.', ephemeral: true });
                        }

                        await channel.members.add(userToAdd);
                    }

                    const embed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`Successfully added ${userToAdd.tag} to the ticket.`);

                    await interaction.reply({ embeds: [embed], ephemeral: true });

                    const notificationEmbed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`<@${userToAdd.id}> has been added to the ticket by <@${interaction.user.id}>.`);

                    await channel.send({ embeds: [notificationEmbed] });
                } catch (error) {
                    console.error('Error adding user to ticket:', error);
                    await interaction.reply({ content: 'An error occurred while adding the user to the ticket. Please try again later.', ephemeral: true });
                }

            } else if (subcommand === 'alert' && !group) {
                try {
                    const supportRoles = config.TicketTypes.TicketType1.SupportRole;
                    if (!interaction.member.roles.cache.some(role => supportRoles.includes(role.id))) {
                        return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                    }

                    if (!config.Alert.Enabled) {
                        return interaction.reply({ content: 'Alert feature is disabled.', ephemeral: true });
                    }

                    const ticket = await Ticket.findOne({ channelId: interaction.channel.id });
                    if (!ticket) {
                        return interaction.reply({ content: 'This command can only be used in ticket channels.', ephemeral: true });
                    }

                    const timeDuration = config.Alert.Time;
                    const alertDurationMs = parseDuration(timeDuration);
                    const alertTime = new Date(Date.now() + alertDurationMs);
                    const discordTimestamp = `<t:${Math.floor(alertTime.getTime() / 1000)}:R>`;

                    ticket.alertTime = alertTime;
                    await ticket.save();

                    const alertConfig = config.Alert.Embed;
                    const embed = new EmbedBuilder()
                        .setDescription(alertConfig.Description.join('\n').replace('{user}', `<@${ticket.userId}>`).replace('{time}', discordTimestamp));

                    if (alertConfig.Title) embed.setTitle(alertConfig.Title);
                    if (alertConfig.Color) embed.setColor(alertConfig.Color);
                    if (alertConfig.Footer && alertConfig.Footer.Text) {
                        embed.setFooter({ text: alertConfig.Footer.Text, iconURL: alertConfig.Footer.Icon || null });
                    }
                    if (alertConfig.Image) embed.setImage(alertConfig.Image);
                    if (alertConfig.Thumbnail) embed.setThumbnail(alertConfig.Thumbnail);

                    const closeButton = new ButtonBuilder()
                        .setCustomId(`ticketclose-${ticket.ticketId}`)
                        .setLabel(lang.Tickets.CloseTicketButton)
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔒');

                    const actionRow = new ActionRowBuilder()
                        .addComponents(closeButton);

                    const tagMessage = await interaction.channel.send(`<@${ticket.userId}>`);
                    const alertMessage = await interaction.channel.send({ embeds: [embed], components: [actionRow] });
                    await interaction.reply({ content: 'Alert has been sent.', ephemeral: true });

                    setTimeout(() => tagMessage.delete(), 500);

                    ticket.alertMessageId = alertMessage.id;
                    await ticket.save();
                } catch (error) {
                    console.error('Error sending alert:', error);
                    await interaction.reply({ content: 'An error occurred while sending the alert. Please try again later.', ephemeral: true });
                }

            } else if (group === 'blacklist') {
                if (subcommand === 'add') {
                    try {
                        const userToBlacklist = interaction.options.getUser('user');
                        const reason = interaction.options.getString('reason') || 'No reason provided';
                        const supportRoles = config.Permissions.blacklist;
                        const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                        if (!hasSupportRole) {
                            return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                        }

                        const existingEntry = await Blacklist.findOne({ userId: userToBlacklist.id });
                        if (existingEntry) {
                            return interaction.reply({ content: `${userToBlacklist.tag} is already blacklisted.`, ephemeral: true });
                        }

                        const blacklistEntry = new Blacklist({
                            userId: userToBlacklist.id,
                            addedBy: interaction.user.id,
                            addedAt: new Date(),
                            reason: reason
                        });

                        await blacklistEntry.save();

                        const embed = new EmbedBuilder()
                            .setColor('#FF0000')
                            .setTitle('🚫 User Blacklisted')
                            .setDescription(`**<@${userToBlacklist.id}>** has been blacklisted from opening tickets.`)
                            .addFields(
                                { name: 'Reason', value: reason, inline: false },
                                { name: 'Blacklisted By', value: `<@${interaction.user.id}>`, inline: true },
                                { name: 'Date', value: `<t:${Math.floor(new Date(blacklistEntry.addedAt).getTime() / 1000)}:F>`, inline: true }
                            )
                            .setThumbnail(userToBlacklist.displayAvatarURL({ dynamic: true }))
                            .setFooter({ text: 'Contact an admin if you believe this is a mistake.' });

                        await interaction.reply({ embeds: [embed], ephemeral: true });
                    } catch (error) {
                        console.error('Error blacklisting user:', error);
                        await interaction.reply({ content: 'An error occurred while blacklisting the user. Please try again later.', ephemeral: true });
                    }
                } else if (subcommand === 'view') {
                    try {
                        const userToCheck = interaction.options.getUser('user');
                        const supportRoles = config.Permissions.blacklist;
                        const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                        if (!hasSupportRole) {
                            return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                        }

                        const blacklistEntry = await Blacklist.findOne({ userId: userToCheck.id });

                        if (!blacklistEntry) {
                            return interaction.reply({ content: `${userToCheck.tag} is not blacklisted.`, ephemeral: true });
                        }

                        const embed = new EmbedBuilder()
                            .setColor('#FFA500')
                            .setTitle('📋 Blacklist Information')
                            .addFields(
                                { name: 'User', value: `<@${blacklistEntry.userId}>`, inline: true },
                                { name: 'Blacklisted By', value: `<@${blacklistEntry.addedBy}>`, inline: true },
                                { name: 'Reason', value: blacklistEntry.reason, inline: false },
                                { name: 'Date', value: `<t:${Math.floor(new Date(blacklistEntry.addedAt).getTime() / 1000)}:F>`, inline: true }
                            )
                            .setThumbnail(userToCheck.displayAvatarURL({ dynamic: true }))
                            .setFooter({ text: 'Contact an admin if you need more information.' });

                        await interaction.reply({ embeds: [embed], ephemeral: true });
                    } catch (error) {
                        console.error('Error fetching blacklist information:', error);
                        await interaction.reply({ content: 'An error occurred while fetching the blacklist information. Please try again later.', ephemeral: true });
                    }
                } else if (subcommand === 'remove' && !group) {
                    try {
                        const userToRemove = interaction.options.getUser('user');
                        const ticket = await Ticket.findOne({ channelId: interaction.channel.id });

                        if (!ticket) {
                            return interaction.reply({ content: 'This command can only be used within a ticket channel.', ephemeral: true });
                        }

                        const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole;
                        const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                        if (!hasSupportRole) {
                            return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                        }

                        const channel = interaction.channel;

                        if (channel.type === ChannelType.GuildText) {
                            const permissions = channel.permissionsFor(userToRemove);
                            if (!permissions || !permissions.has(PermissionFlagsBits.ViewChannel)) {
                                return interaction.reply({ content: 'User is not part of this ticket.', ephemeral: true });
                            }

                            await channel.permissionOverwrites.delete(userToRemove);
                        } else if (channel.type === ChannelType.PrivateThread || channel.type === ChannelType.PublicThread) {
                            const members = await channel.members.fetch();
                            if (!members.has(userToRemove.id)) {
                                return interaction.reply({ content: 'User is not part of this ticket.', ephemeral: true });
                            }

                            await channel.members.remove(userToRemove);
                        }

                        const embed = new EmbedBuilder()
                            .setColor('#FF0000')
                            .setDescription(`Successfully removed ${userToRemove.tag} from the ticket.`);

                        await interaction.reply({ embeds: [embed], ephemeral: true });

                        const notificationEmbed = new EmbedBuilder()
                            .setColor('#FF0000')
                            .setDescription(`<@${userToRemove.id}> has been removed from the ticket by <@${interaction.user.id}>.`);

                        await channel.send({ embeds: [notificationEmbed] });
                    } catch (error) {
                        console.error('Error removing user from ticket:', error);
                        await interaction.reply({ content: 'An error occurred while removing the user from the ticket. Please try again later.', ephemeral: true });
                    }
                }

            } else if (subcommand === 'panel' && !group) {
                try {
                    if (!config.TicketSettings?.Enabled) {
                        return interaction.reply({ content: 'This command has been disabled in the config!', ephemeral: true });
                    }

                    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                        return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                    }

                    const selectedPanel = interaction.options.getString('panel');
                    const panelConfig = config.TicketPanelSettings[selectedPanel];

                    if (!panelConfig) {
                        return interaction.reply({ content: 'Invalid panel selected!', ephemeral: true });
                    }

                    const embedConfig = panelConfig.Embed;

                    const currentTime = moment().tz(config.WorkingHours.Timezone);
                    const workingHoursPlaceholders = {};

                    Object.keys(config.WorkingHours.Schedule).forEach(day => {
                        const [start, end] = config.WorkingHours.Schedule[day].split('-');
                        workingHoursPlaceholders[`workinghours_start_${day.toLowerCase()}`] = `<t:${moment.tz(start, 'HH:mm', config.WorkingHours.Timezone).unix()}:t>`;
                        workingHoursPlaceholders[`workinghours_end_${day.toLowerCase()}`] = `<t:${moment.tz(end, 'HH:mm', config.WorkingHours.Timezone).unix()}:t>`;
                    });

                    const combinedPlaceholders = { ...workingHoursPlaceholders };

                    const embed = new EmbedBuilder()
                        .setColor(embedConfig.Color || '#0099ff')
                        .setDescription(replacePlaceholders((embedConfig.Description || []).join('\n'), combinedPlaceholders));

                    if (embedConfig.Title) {
                        embed.setTitle(replacePlaceholders(embedConfig.Title, combinedPlaceholders));
                    }

                    if (embedConfig.Footer?.Text || embedConfig.Footer?.Icon) {
                        embed.setFooter({
                            text: replacePlaceholders(embedConfig.Footer.Text || '', combinedPlaceholders),
                            iconURL: embedConfig.Footer.Icon || null
                        });
                    }

                    if (embedConfig.Author?.Text || embedConfig.Author?.Icon) {
                        embed.setAuthor({
                            name: replacePlaceholders(embedConfig.Author.Text || '', combinedPlaceholders),
                            iconURL: embedConfig.Author.Icon || null
                        });
                    }

                    if (isValidHttpUrl(embedConfig.Image)) embed.setImage(embedConfig.Image);
                    if (isValidHttpUrl(embedConfig.Thumbnail)) embed.setThumbnail(embedConfig.Thumbnail);

                    if (embedConfig.embedFields && Array.isArray(embedConfig.embedFields)) {
                        embedConfig.embedFields.forEach(field => {
                            const name = replacePlaceholders(field.name, combinedPlaceholders);
                            const value = replacePlaceholders(field.value, combinedPlaceholders);
                            if (name && value) {
                                embed.addFields({
                                    name: name,
                                    value: value,
                                    inline: field.inline || false
                                });
                            }
                        });
                    }

                    const { useSelectMenu } = config.TicketSettings;

                    const rows = [];
                    let currentRow = new ActionRowBuilder();

                    if (useSelectMenu) {
                        const selectMenu = new StringSelectMenuBuilder()
                            .setCustomId('ticketcreate')
                            .setPlaceholder('Select a ticket type');

                        Object.keys(config.TicketTypes).forEach(key => {
                            const ticketType = config.TicketTypes[key];
                            if (ticketType.Enabled && ticketType.Panel === selectedPanel) {
                                selectMenu.addOptions({
                                    label: replacePlaceholders(ticketType.Button.Name || 'Unnamed Ticket', combinedPlaceholders),
                                    emoji: ticketType.Button.Emoji || '',
                                    value: key,
                                    description: replacePlaceholders(ticketType.Button.Description || '', combinedPlaceholders)
                                });
                            }
                        });

                        if (selectMenu.options.length > 0) {
                            currentRow.addComponents(selectMenu);
                            rows.push(currentRow);
                        } else {
                            throw new Error('No ticket types are enabled for this panel.');
                        }
                    } else {
                        Object.keys(config.TicketTypes).forEach(key => {
                            const ticketType = config.TicketTypes[key];
                            if (ticketType.Enabled && ticketType.Panel === selectedPanel) {
                                const buttonStyle = ButtonStyle[ticketType.Button.Style.toUpperCase()] || ButtonStyle.Primary;
                                currentRow.addComponents(
                                    new ButtonBuilder()
                                        .setCustomId(`ticketcreate-${key}`)
                                        .setLabel(replacePlaceholders(ticketType.Button.Name || 'Unnamed Ticket', combinedPlaceholders))
                                        .setEmoji(ticketType.Button.Emoji || '')
                                        .setStyle(buttonStyle)
                                );

                                if (currentRow.components.length === 5) {
                                    rows.push(currentRow);
                                    currentRow = new ActionRowBuilder();
                                }
                            }
                        });

                        if (currentRow.components.length > 0) {
                            rows.push(currentRow);
                        }

                        if (rows.length === 0) {
                            throw new Error('No buttons are enabled for this panel.');
                        }
                    }

                    await interaction.reply({ content: 'Ticket panel sent!', ephemeral: true });
                    await interaction.channel.send({ embeds: [embed], components: rows });
                } catch (error) {
                    console.error('Error sending ticket panel:', error);
                    if (!interaction.replied && !interaction.deferred) {
                        await interaction.reply({ content: 'An error occurred while sending the ticket panel.', ephemeral: true }).catch(e => console.error('Error sending reply:', e));
                    } else {
                        await interaction.followUp({ content: 'An error occurred while sending the ticket panel.', ephemeral: true }).catch(e => console.error('Error sending follow-up:', e));
                    }
                }
            } else if (subcommand === 'voice' && !group) {
                try {
                    const ticket = await Ticket.findOne({ channelId: interaction.channel.id });

                    if (!ticket) {
                        return interaction.reply({ content: 'This command can only be used within a ticket channel.', ephemeral: true });
                    }

                    const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole;
                    const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                    if (!hasSupportRole) {
                        return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                    }

                    const voiceChannel = await interaction.guild.channels.create({
                        name: `${interaction.channel.name}-voice`,
                        type: ChannelType.GuildVoice,
                        parent: interaction.channel.parent,
                    });

                    await voiceChannel.permissionOverwrites.create(interaction.guild.roles.everyone, {
                        ViewChannel: false,
                    });

                    await voiceChannel.permissionOverwrites.create(interaction.user.id, {
                        ViewChannel: true,
                        Connect: true,
                        Speak: true,
                    });

                    for (const roleId of supportRoles) {
                        const role = await interaction.guild.roles.fetch(roleId);
                        if (role) {
                            await voiceChannel.permissionOverwrites.create(role, {
                                ViewChannel: true,
                                Connect: true,
                                Speak: true,
                            });
                        }
                    }

                    await interaction.reply({ content: `Temporary voice channel created: ${voiceChannel}`, ephemeral: true });

                    const checkEmptyChannel = async () => {
                        const channel = await interaction.guild.channels.fetch(voiceChannel.id);
                        if (channel && channel.members.size === 0) {
                            setTimeout(async () => {
                                const channelToDelete = await interaction.guild.channels.fetch(voiceChannel.id);
                                if (channelToDelete && channelToDelete.members.size === 0) {
                                    await channelToDelete.delete();
                                }
                            }, 150000);
                        }
                    };

                    interaction.client.on('voiceStateUpdate', (oldState, newState) => {
                        if (oldState.channelId === voiceChannel.id || newState.channelId === voiceChannel.id) {
                            checkEmptyChannel();
                        }
                    });

                    checkEmptyChannel();
                } catch (error) {
                    console.error('Error creating voice channel:', error);
                    await interaction.reply({ content: 'An error occurred while creating the voice channel. Please try again later.', ephemeral: true });
                }
            } else if (subcommand === 'remove' && !group) {
                try {
                    const userToRemove = interaction.options.getUser('user');
                    const ticket = await Ticket.findOne({ channelId: interaction.channel.id });

                    if (!ticket) {
                        return interaction.reply({ content: 'This command can only be used within a ticket channel.', ephemeral: true });
                    }

                    const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole;
                    const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                    if (!hasSupportRole) {
                        return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                    }

                    const channel = interaction.channel;

                    if (channel.type === ChannelType.GuildText) {
                        const permissions = channel.permissionsFor(userToRemove);
                        if (!permissions || !permissions.has(PermissionFlagsBits.ViewChannel)) {
                            return interaction.reply({ content: 'User is not part of this ticket.', ephemeral: true });
                        }

                        await channel.permissionOverwrites.delete(userToRemove);
                    } else if (channel.type === ChannelType.PrivateThread || channel.type === ChannelType.PublicThread) {
                        const members = await channel.members.fetch();
                        if (!members.has(userToRemove.id)) {
                            return interaction.reply({ content: 'User is not part of this ticket.', ephemeral: true });
                        }

                        await channel.members.remove(userToRemove);
                    } else {
                        return interaction.reply({ content: 'This command can only be used within a text channel or thread.', ephemeral: true });
                    }

                    const embed = new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription(`Successfully removed ${userToRemove.tag} from the ticket.`);

                    await interaction.reply({ embeds: [embed], ephemeral: true });

                    const notificationEmbed = new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription(`<@${userToRemove.id}> has been removed from the ticket by <@${interaction.user.id}>.`);

                    await channel.send({ embeds: [notificationEmbed] });
                } catch (error) {
                    console.error('Error removing user from ticket:', error);
                    await interaction.reply({ content: 'An error occurred while removing the user from the ticket. Please try again later.', ephemeral: true });
                }

            } else if (subcommand === 'rename' && !group) {
                try {
                    const newName = interaction.options.getString('name');
                    const ticket = await Ticket.findOne({ channelId: interaction.channel.id });

                    if (!ticket) {
                        return interaction.reply({ content: 'This command can only be used within a ticket channel.', ephemeral: true });
                    }

                    const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole;
                    const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                    if (!hasSupportRole) {
                        return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                    }

                    const channel = interaction.channel;

                    await channel.setName(newName);

                    const embed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`Successfully renamed the ticket to ${newName}.`);

                    await interaction.reply({ embeds: [embed], ephemeral: true });

                    const notificationEmbed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`The ticket has been renamed to ${newName} by <@${interaction.user.id}>.`);

                    await channel.send({ embeds: [notificationEmbed] });
                } catch (error) {
                    console.error('Error renaming ticket:', error);
                    await interaction.reply({ content: 'An error occurred while renaming the ticket. Please try again later.', ephemeral: true });
                }

            } else if (subcommand === 'stats' && !group) {
                try {
                    if (!hasSupportRole(interaction.member, Object.values(config.TicketTypes).flatMap(type => type.SupportRole))) {
                        await interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                        return;
                    }

                    const totalTickets = await Ticket.countDocuments({});
                    const openTickets = await Ticket.countDocuments({ status: 'open' });
                    const closedTickets = await Ticket.countDocuments({ status: 'closed' });
                    const deletedTickets = await Ticket.countDocuments({ status: 'deleted' });

                    const tickets = await Ticket.find({});
                    const totalMessages = tickets.reduce((sum, ticket) => sum + (ticket.messageCount || 0), 0);

                    const validReviews = tickets.filter(ticket => {
                        const ratingMatch = ticket.rating.match(/\((\d)\/5\)$/);
                        if (ratingMatch) {
                            ticket.numericRating = parseInt(ratingMatch[1]);
                            return true;
                        }
                        return false;
                    });

                    const totalReviews = validReviews.length;
                    const averageRating = totalReviews > 0 ? (validReviews.reduce((sum, ticket) => sum + ticket.numericRating, 0) / totalReviews).toFixed(1) : 'N/A';
                    const averageRatingStars = totalReviews > 0 ? `${'⭐'.repeat(Math.floor(averageRating))} \`${averageRating}/5\`` : 'No Ratings';

                    const deletedTicketsWithTimes = tickets.filter(ticket => ticket.status === 'deleted' && ticket.closedAt && ticket.createdAt);
                    const totalClosureTime = deletedTicketsWithTimes.reduce((sum, ticket) => {
                        const createdAt = moment(ticket.createdAt);
                        const closedAt = moment(ticket.closedAt);
                        return sum + closedAt.diff(createdAt);
                    }, 0);
                    const averageClosureTime = deletedTicketsWithTimes.length > 0 ? totalClosureTime / deletedTicketsWithTimes.length : 0;
                    const formattedClosureTime = formatDuration(averageClosureTime);

                    const longestClosureTime = Math.max(...deletedTicketsWithTimes.map(ticket => moment(ticket.closedAt).diff(moment(ticket.createdAt))), 0);
                    const formattedLongestClosureTime = formatDuration(longestClosureTime);

                    const graphBase64 = await generateTicketsGraph(tickets);
                    const graphBuffer = Buffer.from(graphBase64, 'base64');
                    const attachment = new AttachmentBuilder(graphBuffer, { name: 'tickets_graph.png' });

                    const placeholders = {
                        totalTickets,
                        totalMessages,
                        totalReviews,
                        openTickets,
                        closedTickets,
                        deletedTickets,
                        averageRating: averageRatingStars,
                        averageClosure: formattedClosureTime,
                        maxClosure: formattedLongestClosureTime,
                        user: `<@${interaction.user.id}>`
                    };

                    const embedConfig = lang.Stats.Embed;
                    const statsEmbed = new EmbedBuilder()
                        .setTitle(replacePlaceholders(embedConfig.Title, placeholders))
                        .setColor(embedConfig.Color)
                        .setDescription(embedConfig.Description.map(line => replacePlaceholders(line, placeholders)).join('\n'))
                        .setTimestamp();

                    if (embedConfig.Footer && embedConfig.Footer.Text) {
                        statsEmbed.setFooter({
                            text: replacePlaceholders(embedConfig.Footer.Text, placeholders),
                            iconURL: embedConfig.Footer.Icon
                        });
                    }

                    if (embedConfig.Author && embedConfig.Author.Text) {
                        statsEmbed.setAuthor({
                            name: replacePlaceholders(embedConfig.Author.Text, placeholders),
                            iconURL: embedConfig.Author.Icon
                        });
                    }

                    if (embedConfig.Image) {
                        statsEmbed.setImage('attachment://tickets_graph.png');
                    }

                    if (embedConfig.Thumbnail) {
                        statsEmbed.setThumbnail(embedConfig.Thumbnail);
                    }

                    if (Array.isArray(embedConfig.Fields)) {
                        embedConfig.Fields.forEach(field => {
                            if (field.name && field.value) {
                                statsEmbed.addFields({
                                    name: replacePlaceholders(field.name, placeholders),
                                    value: replacePlaceholders(field.value, placeholders),
                                    inline: field.inline
                                });
                            }
                        });
                    }

                    await interaction.reply({ embeds: [statsEmbed], files: [attachment], ephemeral: false });
                } catch (error) {
                    console.error('Error fetching ticket stats:', error);
                    await interaction.reply({ content: 'An error occurred while fetching ticket stats. Please try again later.', ephemeral: true });
                }

            } else if (subcommand === 'close' && !group) {
                try {
                    const reason = interaction.options.getString('reason') || lang.NoReason;
                    const ticket = await Ticket.findOne({ channelId: interaction.channel.id });

                    if (!ticket) {
                        return interaction.reply({ content: 'This command can only be used within a ticket channel.', ephemeral: true });
                    }

                    const supportRoles = config.TicketTypes[ticket.ticketType].SupportRole;
                    const hasSupportRole = interaction.member.roles.cache.some(role => supportRoles.includes(role.id));

                    if (!hasSupportRole) {
                        return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
                    }

                    await interaction.deferReply({ ephemeral: true });

                    await handleTicketClose(interaction.client, interaction, ticket.ticketId);

                    await interaction.editReply({ content: 'Ticket closed successfully.' });
                } catch (error) {
                    console.error('Error closing ticket:', error);
                    if (!interaction.replied && !interaction.deferred) {
                        await interaction.reply({ content: 'An error occurred while closing the ticket. Please try again later.', ephemeral: true });
                    } else {
                        await interaction.editReply({ content: 'An error occurred while closing the ticket. Please try again later.' });
                    }
                }
            }
            else if (subcommand === 'transfer' && !group) {
                try {
                    await interaction.deferReply({ ephemeral: true });

                    const newType = interaction.options.getString('type');
                    const ticket = await Ticket.findOne({ channelId: interaction.channel.id });

                    if (!ticket) {
                        return interaction.editReply({ content: 'This command can only be used within a ticket channel.' });
                    }

                    const oldTicketType = config.TicketTypes[ticket.ticketType];
                    const newTicketType = config.TicketTypes[newType];

                    if (!newTicketType) {
                        return interaction.editReply({ content: 'New ticket type not found.' });
                    }

                    if (ticket.ticketType === newType) {
                        return interaction.editReply({ content: 'This ticket is already of the specified type.' });
                    }

                    const hasSupportRole = interaction.member.roles.cache.some(role => oldTicketType.SupportRole.includes(role.id));

                    if (!hasSupportRole) {
                        return interaction.editReply({ content: lang.NoPermsMessage });
                    }

                    const channel = await interaction.guild.channels.fetch(ticket.channelId);
                    if (!channel) {
                        return interaction.editReply({ content: 'Channel not found.' });
                    }

                    const member = await interaction.guild.members.fetch(ticket.userId);
                    const userPriority = await getUserPriority(member);

                    const newCategoryId = newTicketType.CategoryID && newTicketType.CategoryID !== "" ? newTicketType.CategoryID : null;

                    try {
                        await moveChannel(channel, newCategoryId);
                        await updateChannelPermissions(channel, newTicketType, ticket.userId);
                    } catch (error) {
                        console.error('Error during channel operations:', error);
                        return interaction.editReply({ content: 'An error occurred while transferring the ticket. Please try again later.' });
                    }

                    ticket.questions = ticket.questions.map(q => ({
                        question: q.question || 'No Question Provided',
                        answer: q.answer || 'No Answer Provided'
                    }));

                    ticket.ticketType = newType;
                    await ticket.save();

                    const newName = newTicketType.ChannelName.replace('{ticket-id}', ticket.ticketId)
                        .replace('{user}', interaction.user.username)
                        .replace('{priority}', userPriority);

                    try {
                        await renameChannel(channel, newName);
                    } catch (error) {
                        console.error('Error during channel rename:', error);
                        return interaction.editReply({ content: 'An error occurred while renaming the ticket. Please try again later.' });
                    }

                    const successEmbed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`Successfully transferred the ticket to ${newTicketType.Name}.`);
                    await interaction.editReply({ embeds: [successEmbed] });

                    const notificationEmbed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`Ticket has been transferred to ${newTicketType.Name} by <@${interaction.user.id}>.`);
                    await channel.send({ embeds: [notificationEmbed] });

                } catch (error) {
                    console.error('Error transferring ticket:', error);
                    await interaction.editReply({ content: 'An error occurred while transferring the ticket. Please try again later.' });
                }
            } else {
                await interaction.reply({ content: 'Invalid subcommand.', ephemeral: true });
            }
        } catch (error) {
            console.error('Error executing command:', error);
            await interaction.reply({ content: 'An error occurred while executing the command. Please try again later.', ephemeral: true });
        }
    }
};