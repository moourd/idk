﻿const { EmbedBuilder, SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const axios = require('axios');
const yaml = require('js-yaml');
const fs = require('fs');
const Transaction = require('../../models/Transaction');
const rateLimit = new Map();

const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'));
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));

module.exports = {
    data: new SlashCommandBuilder()
        .setName('crypto')
        .setDescription('Generate a crypto payment embed')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Client user')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('coin')
                .setDescription('Cryptocurrency type')
                .setRequired(true)
                .addChoices(
                    { name: 'Bitcoin (BTC)', value: 'BTC' },
                    { name: 'Litecoin (LTC)', value: 'LTC' },
                    { name: 'Ethereum (ETH)', value: 'ETH' },
                    { name: 'Dogecoin (DOGE)', value: 'DOGE' }
                ))
        .addStringOption(option =>
            option.setName('price')
                .setDescription('Price in currency format (e.g., $5.99, £2.56, €4.2)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('predefined_wallet')
                .setDescription('Select a predefined wallet address')
                .setRequired(false)
                .addChoices(
                    { name: 'BTC', value: 'BTC' },
                    { name: 'LTC', value: 'LTC' },
                    { name: 'ETH', value: 'ETH' },
                    { name: 'USDT', value: 'USDT' },
                    { name: 'BNB', value: 'BNB' },
                    { name: 'USDC', value: 'USDC' },
                    { name: 'XRP', value: 'XRP' },
                    { name: 'DOGE', value: 'DOGE' },
                    { name: 'SOL', value: 'SOL' },
                    { name: 'DOT', value: 'DOT' },
                    { name: 'TRX', value: 'TRX' },
                    { name: 'MATIC', value: 'MATIC' },
                    { name: 'SHIB', value: 'SHIB' },
                    { name: 'AVAX', value: 'AVAX' }
                ))
        .addStringOption(option =>
            option.setName('custom_wallet')
                .setDescription('Enter a custom wallet address')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('product')
                .setDescription('Product or service description')
                .setRequired(false)),
    async execute(interaction) {
        const requiredRoles = config.Permissions.crypto;
        const hasPermission = requiredRoles.some(roleId => interaction.member.roles.cache.has(roleId));

        if (!hasPermission) {
            return interaction.reply({ content: lang.NoPermsMessage, ephemeral: true });
        }

        const user = interaction.options.getUser('user');
        const coin = interaction.options.getString('coin');
        const price = interaction.options.getString('price');
        const predefinedWallet = interaction.options.getString('predefined_wallet');
        const customWallet = interaction.options.getString('custom_wallet');
        const product = interaction.options.getString('product') || 'N/A';

        const currencySymbol = price.charAt(0);
        const currencyAmount = parseFloat(price.substring(1));
        let currencyCode;

        if (currencySymbol === '$') currencyCode = 'USD';
        else if (currencySymbol === '£') currencyCode = 'GBP';
        else if (currencySymbol === '€') currencyCode = 'EUR';
        else return interaction.reply({ content: 'Unsupported currency symbol.', ephemeral: true });

        let address;
        if (predefinedWallet) {
            address = lang.Wallets[predefinedWallet];
        } else if (customWallet) {
            address = customWallet;
        } else {
            return interaction.reply({ content: 'You must provide either a predefined or custom wallet address.', ephemeral: true });
        }

        const userId = interaction.user.id;
        const currentTime = new Date().getTime();

        if (rateLimit.has(userId)) {
            const { lastSubmission, count } = rateLimit.get(userId);
            if (currentTime - lastSubmission < 60000) {
                if (count >= 5) {
                    return interaction.reply({ content: 'You are submitting transactions too quickly. Please wait a moment.', ephemeral: true });
                } else {
                    rateLimit.set(userId, { lastSubmission: currentTime, count: count + 1 });
                }
            } else {
                rateLimit.set(userId, { lastSubmission: currentTime, count: 1 });
            }
        } else {
            rateLimit.set(userId, { lastSubmission: currentTime, count: 1 });
        }

        try {
            const response = await axios.get(`https://api.coinbase.com/v2/exchange-rates?currency=${coin}`);
            const rates = response.data.data.rates;
            const conversionRate = parseFloat(rates[currencyCode]);
            const cryptoAmount = (currencyAmount / conversionRate).toFixed(8);

            const coinFullNames = {
                'BTC': 'Bitcoin',
                'ETH': 'Ethereum',
                'USDT': 'Tether',
                'BNB': 'Binance Coin',
                'USDC': 'USD Coin',
                'XRP': 'XRP',
                'ADA': 'Cardano',
                'DOGE': 'Dogecoin',
                'SOL': 'Solana',
                'DOT': 'Polkadot',
                'TRX': 'TRON',
                'MATIC': 'Polygon',
                'LTC': 'Litecoin',
                'SHIB': 'Shiba Inu',
                'AVAX': 'Avalanche',
            };
            const coinTypeFull = coinFullNames[coin] || coin;

            const coinIcons = {
                'BTC': 'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
                'ETH': 'https://cryptologos.cc/logos/ethereum-eth-logo.png',
                'USDT': 'https://cryptologos.cc/logos/tether-usdt-logo.png',
                'BNB': 'https://cryptologos.cc/logos/binance-coin-bnb-logo.png',
                'USDC': 'https://cryptologos.cc/logos/usd-coin-usdc-logo.png',
                'XRP': 'https://cryptologos.cc/logos/xrp-xrp-logo.png',
                'ADA': 'https://cryptologos.cc/logos/cardano-ada-logo.png',
                'DOGE': 'https://cryptologos.cc/logos/dogecoin-doge-logo.png',
                'SOL': 'https://cryptologos.cc/logos/solana-sol-logo.png',
                'DOT': 'https://cryptologos.cc/logos/polkadot-dot-logo.png',
                'TRX': 'https://cryptologos.cc/logos/tron-trx-logo.png',
                'MATIC': 'https://cryptologos.cc/logos/polygon-matic-logo.png',
                'LTC': 'https://cryptologos.cc/logos/litecoin-ltc-logo.png',
                'SHIB': 'https://cryptologos.cc/logos/shiba-inu-shib-logo.png',
                'AVAX': 'https://cryptologos.cc/logos/avalanche-avax-logo.png',
            };
            const coinIcon = coinIcons[coin] || '';

            const qrCodeURL = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(address)}&size=150x150`;

            const thumbnailURL = lang.Crypto.Embed.Thumbnail === '{qrCode}' ? qrCodeURL : coinIcon;

            const embed = new EmbedBuilder()
                .setTitle(lang.Crypto.Embed.Title.replace('{coinType}', coin).replace('{coinType_Full}', coinTypeFull))
                .setDescription(lang.Crypto.Embed.Description.join('\n')
                    .replace('{seller}', `<@${interaction.user.id}>`)
                    .replace('{client}', `<@${user.id}>`)
                    .replace('{service}', product)
                    .replace('{walletAddress}', address)
                    .replace('{cryptoAmount}', cryptoAmount)
                    .replace('{currencySymbol}', currencySymbol)
                    .replace('{currencyAmount}', currencyAmount)
                    .replace('{status}', lang.Crypto.Messages.Pending.Lang)
                    .replace('{transaction}', lang.Crypto.Messages.Transaction))
                .setFooter({ text: lang.Crypto.Embed.Footer.Text, iconURL: lang.Crypto.Embed.Footer.Icon })
                .setColor(lang.Crypto.Messages.Pending.Color)
                .setThumbnail(thumbnailURL);

            const buttons = lang.Crypto.Embed.Buttons.map(buttonConfig => {
                const style = ButtonStyle[buttonConfig.Style];

                if (!style) {
                    throw new Error(`Invalid button style: ${buttonConfig.Style}`);
                }

                const button = new ButtonBuilder()
                    .setLabel(buttonConfig.Name)
                    .setEmoji(buttonConfig.Emoji)
                    .setStyle(style);

                if (buttonConfig.Type === 'LINK') {
                    button.setURL(buttonConfig.Link);
                } else {
                    button.setCustomId(`crypto_${buttonConfig.Type.toLowerCase()}`);
                }

                return button;
            });

            const row = new ActionRowBuilder().addComponents(buttons);

            const reply = await interaction.reply({ embeds: [embed], components: [row], ephemeral: false });
            const replyMessage = await interaction.fetchReply();

            const transaction = new Transaction({
                messageId: replyMessage.id,
                userId: interaction.user.id,
                address,
                qrCodeURL,
                status: 'Pending',
                coin: coin,
                channelId: interaction.channel.id,
                commandTimestamp: new Date(),
                requestedAmount: cryptoAmount,
                targetAddress: address
            });

            await transaction.save();
        } catch (error) {
            console.error('Error fetching conversion rates:', error);
            await interaction.reply({ content: 'There was an error fetching the conversion rates. Please try again later.', ephemeral: true });
        }
    },
};