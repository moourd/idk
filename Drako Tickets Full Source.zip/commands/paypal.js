const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const axios = require('axios');
const fs = require('fs');
const yaml = require('js-yaml');
const Invoice = require('../models/invoice');

const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'));
const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'));

const isSandbox = config.PayPalSettings.Sandbox || false;
const paypalApiBaseUrl = isSandbox ? 'https://api.sandbox.paypal.com' : 'https://api.paypal.com';

function replacePlaceholders(text, replacements) {
    return text.replace(/{(.*?)}/g, (_, key) => replacements[key] || '');
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('paypal')
        .setDescription('Create a PayPal invoice')
        .addUserOption(option => option.setName('user').setDescription('The user to bill').setRequired(true))
        .addStringOption(option => option.setName('price').setDescription('The price of the product').setRequired(true))
        .addStringOption(option => option.setName('product').setDescription('The product or service').setRequired(true)),

    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const price = interaction.options.getString('price');
        const product = interaction.options.getString('product');

        const replacements = {
            seller: config.PayPalSettings.Email,
            buyer: `<@${user.id}>`,
            invoiceID: '',
            currency: config.PayPalSettings.Currency,
            price: `${config.PayPalSettings.Symbol}${price}`,
            service: product,
            status: lang.Paypal.Messages.Unpaid.Message,
        };

        try {
            const authResponse = await axios({
                method: 'post',
                url: `${paypalApiBaseUrl}/v1/oauth2/token`,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': `Basic ${Buffer.from(`${config.PayPalSettings.ClientID}:${config.PayPalSettings.Secret}`).toString('base64')}`
                },
                data: 'grant_type=client_credentials'
            });

            const accessToken = authResponse.data.access_token;

            const invoiceResponse = await axios({
                method: 'post',
                url: `${paypalApiBaseUrl}/v2/invoicing/invoices`,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`
                },
                data: {
                    detail: {
                        currency_code: config.PayPalSettings.Currency,
                        note: product,
                        terms_and_conditions: "Thank you for your business.",
                        invoice_date: new Date().toISOString().split('T')[0]
                    },
                    invoicer: {
                        name: { given_name: "Seller", surname: "Name" },
                        email_address: config.PayPalSettings.Email
                    },
                    primary_recipients: [{
                        billing_info: {
                            email_address: config.PayPalSettings.Email // Set to PayPalSettings.Email
                        }
                    }],
                    items: [
                        {
                            name: product,
                            quantity: 1,
                            unit_amount: {
                                currency_code: config.PayPalSettings.Currency,
                                value: price
                            }
                        }
                    ],
                    amount: {
                        breakdown: {
                            item_total: {
                                currency_code: config.PayPalSettings.Currency,
                                value: price
                            }
                        }
                    }
                }
            });

            const paypalInvoiceUrl = invoiceResponse.data.href;
            const paypalInvoiceId = paypalInvoiceUrl.split('/').pop();

            if (!paypalInvoiceId) {
                throw new Error('Invoice ID not found in the response');
            }

            await axios({
                method: 'post',
                url: `${paypalApiBaseUrl}/v2/invoicing/invoices/${paypalInvoiceId}/send`,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`
                }
            });

            replacements.invoiceID = paypalInvoiceId;

            const embed = new EmbedBuilder();

            if (lang.Paypal.Embed.Title) {
                embed.setTitle(replacePlaceholders(lang.Paypal.Embed.Title, replacements));
            }

            if (lang.Paypal.Embed.Description) {
                const description = lang.Paypal.Embed.Description.map(line => replacePlaceholders(line, replacements)).join('\n');
                embed.setDescription(description);
            }

            if (lang.Paypal.Embed.Fields) {
                lang.Paypal.Embed.Fields.forEach(field => {
                    if (field.name && field.value) {
                        embed.addFields({
                            name: replacePlaceholders(field.name, replacements),
                            value: replacePlaceholders(field.value, replacements),
                            inline: field.inline
                        });
                    }
                });
            }

            if (lang.Paypal.Embed.Footer.Text) {
                embed.setFooter({
                    text: replacePlaceholders(lang.Paypal.Embed.Footer.Text, replacements),
                    iconURL: lang.Paypal.Embed.Footer.Icon || undefined
                });
            }

            if (lang.Paypal.Embed.Author.Text) {
                embed.setAuthor({
                    name: replacePlaceholders(lang.Paypal.Embed.Author.Text, replacements),
                    iconURL: lang.Paypal.Embed.Author.Icon || undefined
                });
            }

            if (lang.Paypal.Embed.Image) {
                embed.setImage(lang.Paypal.Embed.Image);
            }

            if (lang.Paypal.Embed.Thumbnail) {
                embed.setThumbnail(lang.Paypal.Embed.Thumbnail);
            }

            embed.setColor(lang.Paypal.Messages.Unpaid.Color);

            const buttons = new ActionRowBuilder();
            if (lang.Paypal.Embed.Buttons.Pay.Name) {
                buttons.addComponents(
                    new ButtonBuilder()
                        .setLabel(replacePlaceholders(lang.Paypal.Embed.Buttons.Pay.Name, replacements))
                        .setStyle(ButtonStyle.Link)
                        .setURL(`https://www.${isSandbox ? 'sandbox.' : ''}paypal.com/invoice/p/#${paypalInvoiceId}`)
                        .setEmoji(lang.Paypal.Embed.Buttons.Pay.Emoji)
                );
            }
            if (lang.Paypal.Embed.Buttons.Status.Name) {
                buttons.addComponents(
                    new ButtonBuilder()
                        .setLabel(replacePlaceholders(lang.Paypal.Embed.Buttons.Status.Name, replacements))
                        .setStyle(ButtonStyle.Success)
                        .setCustomId(`paypal_updateStatus_${paypalInvoiceId}`)
                        .setEmoji(lang.Paypal.Embed.Buttons.Status.Emoji)
                );
            }

            const sentMessage = await interaction.reply({ embeds: [embed], components: [buttons], fetchReply: true });

            const newInvoice = new Invoice({
                userId: user.id,
                price,
                product,
                invoiceId: paypalInvoiceId,
                status: 'UNPAID',
                messageId: sentMessage.id,
                channelId: interaction.channel.id,
                guildId: interaction.guild.id
            });

            await newInvoice.save();

        } catch (error) {
            console.error('Error creating PayPal invoice:', error.response ? error.response.data : error.message);
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: lang.Paypal.Messages.Error, ephemeral: true });
            } else if (interaction.deferred) {
                await interaction.followUp({ content: lang.Paypal.Messages.Error, ephemeral: true });
            }
        }
    }
};